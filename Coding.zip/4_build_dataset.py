"""
GenerativeAURORA v2 - 4_build_dataset.py
========================================
Turns Dataset/processed/himawari_qc.parquet into model-ready day-ahead samples.

FORECAST TASK (stated once, used everywhere)
  Issue time : end of day D-1 (local time).
  Output     : 16 hourly values of the clear-sky index k_c for day D,
               clock hours 05:00-20:00 local standard time.
  Allowed inputs, all known at issue time:
    x_past   day D-1, 16 hours: observed irradiance, k_c, weather, satellite
             cloud classes, fill flag                              -> [N,16,Fp]
    x_hist   daily mean k_c of days D-7 ... D-1                    -> [N,7]
    x_future day D, 16 hours: SUN GEOMETRY ONLY (cos zenith, hour angle,
             day of year). Deterministic, so no future information. -> [N,16,Ff]
    x_static pixel latitude, longitude, elevation and the site's monthly k_c
             climatology from TRAINING years only. No site ID anywhere, so a
             new location only needs coordinates + its satellite history.
  NOT inputs: anything measured on day D. Day-D clear-sky GHI (it uses day-D
  aerosol) is stored only to convert k_c -> W/m2 for evaluation, as an
  operational system would do with an aerosol forecast (e.g. CAMS).

MASKS (fixes the Paper 1 padding problem)
  m_y = 1 only where the target is real: sun above 5 deg (zenith < 85),
  clear-sky GHI > 50 W/m2, and fill_flag not in TARGET_EXCLUDE_FILL.
  Night and excluded hours are 0 and MUST be ignored by loss and metrics.

SPLITS (two independent temporal tests, decided by forecast day D)
  split_main : train 2016-18 | val/cal 2019 odd/even ISO weeks | test 2020
  split_alt  : train 2016-17 | val/cal 2018 odd/even ISO weeks | test 2019
  Normalisation statistics use 2016-2017 only (training years of BOTH splits).

Outputs
  Dataset/processed/aurora_dataset.npz   all arrays
  Dataset/processed/aurora_dataset.json  feature names, normalisation, settings
  Results/dataset/dataset_report.txt     report (send to Claude)

Usage:
    python 4_build_dataset.py
"""

import os
import sys
import json
import warnings
import importlib
from datetime import datetime, date

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
cfg = importlib.import_module("1_config")

# ----------------------------------------------------------------------------
# Settings for this step
# ----------------------------------------------------------------------------
HOURS = list(range(5, 21))          # 16 clock hours, 05:00-20:00 local standard time
ZENITH_MAX = 85.0                   # target only where sun is > 5 deg high
CLEARSKY_MIN = 50.0                 # W/m2, avoid k_c blow-up at dawn/dusk
TARGET_EXCLUDE_FILL = [1, 2, 4, 5]  # missing image, low irr., missing cloud props, Rayleigh
                                    # (3 = 'exceeds clear sky' = capped at clear sky -> kept)
MIN_VALID_TARGET_HOURS = 6          # drop days with fewer real target hours
HIST_DAYS = 7
NORM_YEARS = [2016, 2017]

# Satellite cloud_type codes -> 4 physical groups (others: all zeros)
CLOUD_GROUPS = {"cloud_clear": [0, 1], "cloud_liquid": [2, 3, 4],
                "cloud_cirrus": [7], "cloud_thick": [5, 6, 8, 9]}

# Day-D regime for EVALUATION ONLY, from satellite cloud classes (not from GHI)
REGIME_CLEAR_MIN = 0.5    # >= 50 % of target hours clear/probably clear -> Clear
REGIME_OVERCAST_MIN = 0.7 # >= 70 % of target hours thick cloud         -> Overcast
REGIMES = ["Clear", "Cloudy", "Overcast"]

# Optional weather columns: first name that exists in the parquet is used
WEATHER_CANDIDATES = {
    "temperature": ["temperature", "air_temperature"],
    "relative_humidity": ["relative_humidity"],
    "dew_point": ["dew_point"],
    "pressure": ["pressure", "surface_pressure"],
    "wind_speed": ["wind_speed"],
    "precipitable_water": ["precipitable_water", "total_precipitable_water"],
    "aod": ["aod", "aerosol_optical_depth"],
    "surface_albedo": ["surface_albedo"],
}

# If 2020 (v3.1.1) labels clouds differently from 2016-2019, set False:
# cloud groups are then removed from the inputs and regimes are defined from
# the day's k_c (evaluation only). Decide from section 3b of the report.
USE_CLOUD_FEATURES = False   # 3b showed: 2020 thick-cloud share z=+6.3 while k_c z=+0.1
                             # -> cloud_type classification changed in v3.1.1
REGIME_KC_CLEAR = 0.85     # used only when USE_CLOUD_FEATURES = False
REGIME_KC_OVERCAST = 0.40

IN_PARQUET = os.path.join(cfg.PROC_DIR, "himawari_qc.parquet")
SITE_META_CSV = os.path.join(cfg.META_DIR, "site_meta.csv")
OUT_NPZ = os.path.join(cfg.PROC_DIR, "aurora_dataset.npz")
OUT_JSON = os.path.join(cfg.PROC_DIR, "aurora_dataset.json")
REP_DIR = os.path.join(cfg.RESULT_DIR, "dataset")
REPORT = os.path.join(REP_DIR, "dataset_report.txt")

_lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    _lines.append(s)


def section(t):
    log("\n" + "=" * 78); log(t); log("=" * 78)


# ----------------------------------------------------------------------------
def split_alt(d):
    if d.year in (2016, 2017):
        return "train"
    if d.year == 2018:
        return "val" if d.isocalendar()[1] % 2 == 1 else "cal"
    if d.year == 2019:
        return "test"
    return "unused"


def hour_angle_deg(local_times, lon, tz):
    t = pd.DatetimeIndex(local_times) - pd.to_timedelta(tz, unit="h")
    doy = t.dayofyear.values
    hour = t.hour.values + t.minute.values / 60.0
    g = 2 * np.pi / 365.0 * (doy - 1 + (hour - 12) / 24)
    eot = 229.18 * (0.000075 + 0.001868 * np.cos(g) - 0.032077 * np.sin(g)
                    - 0.014615 * np.cos(2 * g) - 0.040849 * np.sin(2 * g))
    ha = (hour * 60 + eot + 4 * lon) / 4 - 180
    return (ha + 180) % 360 - 180


def day_matrix(df, col):
    """[n_days, 16] matrix of one variable, rows = calendar date."""
    m = df.pivot_table(index="date", columns="hour", values=col, aggfunc="first")
    return m.reindex(columns=HOURS)


def build_site(g, meta_row, wcols):
    g = g.copy()
    g["date"] = g["time"].dt.date
    g["hour"] = g["time"].dt.hour
    g = g[g["hour"].isin(HOURS)]

    zen = day_matrix(g, "solar_zenith_angle")
    dates = list(zen.index)
    Z = zen.values
    GHI = day_matrix(g, "ghi").values
    CS = day_matrix(g, "clearsky_ghi").values
    DNI = day_matrix(g, "dni").values
    DHI = day_matrix(g, "dhi").values
    FILL = day_matrix(g, "fill_flag").values
    CT = day_matrix(g, "cloud_type").values
    W = {k: day_matrix(g, c).values for k, c in wcols.items()}

    sun = (Z < ZENITH_MAX) & (CS > CLEARSKY_MIN)
    excl = np.isin(FILL, TARGET_EXCLUDE_FILL)
    valid = sun & ~excl
    KC = np.where(sun, np.clip(GHI / np.where(CS > 0, CS, 1.0), 0, 1.2), 0.0)

    # hour angle / geometry per day-hour (deterministic)
    stamps = pd.to_datetime([datetime(d.year, d.month, d.day, h) for d in dates for h in HOURS])
    HA = hour_angle_deg(stamps, meta_row.ret_lon, meta_row.tz).reshape(len(dates), len(HOURS))
    COSZ = np.cos(np.radians(np.clip(Z, 0, 90)))

    # daily mean k_c over valid hours (for history and climatology)
    kc_day = np.where(valid, KC, np.nan)
    with np.errstate(invalid="ignore"), warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        kc_daily = np.nanmean(kc_day, axis=1)
    # satellite regime of each day (evaluation only)
    tgt_h = sun.sum(1).clip(min=1)
    clear_frac = (np.isin(CT, CLOUD_GROUPS["cloud_clear"]) & sun).sum(1) / tgt_h
    thick_frac = (np.isin(CT, CLOUD_GROUPS["cloud_thick"]) & sun).sum(1) / tgt_h
    if USE_CLOUD_FEATURES:
        regime = np.where(clear_frac >= REGIME_CLEAR_MIN, 0,
                          np.where(thick_frac >= REGIME_OVERCAST_MIN, 2, 1))
    else:
        regime = np.where(kc_daily >= REGIME_KC_CLEAR, 0,
                          np.where(kc_daily <= REGIME_KC_OVERCAST, 2, 1))

    date_idx = {d: i for i, d in enumerate(dates)}
    out = []
    for i, d in enumerate(dates):
        prev = date.fromordinal(d.toordinal() - 1)
        if prev not in date_idx:
            continue
        j = date_idx[prev]
        if valid[i].sum() < MIN_VALID_TARGET_HOURS:
            continue
        hist = []
        for k in range(HIST_DAYS, 0, -1):
            dd = date.fromordinal(d.toordinal() - k)
            hist.append(kc_daily[date_idx[dd]] if dd in date_idx else np.nan)
        past = {
            "kc": KC[j], "ghi": GHI[j] / 1000, "dni": DNI[j] / 1000, "dhi": DHI[j] / 1000,
            "cos_zenith": COSZ[j], "valid_past": valid[j].astype(float),
            "filled_past": (FILL[j] > 0).astype(float),
        }
        for k, arr in W.items():
            past[k] = arr[j]
        if USE_CLOUD_FEATURES:
            for name, codes in CLOUD_GROUPS.items():
                past[name] = (np.isin(CT[j], codes) & (Z[j] < 90)).astype(float)
        doy = d.timetuple().tm_yday
        fut = {
            "cos_zenith": COSZ[i], "sun_up": (Z[i] < ZENITH_MAX).astype(float),
            "ha_sin": np.sin(np.radians(HA[i])), "ha_cos": np.cos(np.radians(HA[i])),
            "doy_sin": np.full(len(HOURS), np.sin(2 * np.pi * doy / 366)),
            "doy_cos": np.full(len(HOURS), np.cos(2 * np.pi * doy / 366)),
        }
        out.append(dict(
            date=d, past=past, fut=fut, hist=np.array(hist, dtype=float),
            y=np.where(valid[i], KC[i], 0.0), m_y=valid[i].astype(np.float32),
            cs=np.nan_to_num(CS[i]), ghi=np.nan_to_num(GHI[i]),
            regime_true=int(regime[i]), regime_proxy=int(regime[j]),
            kc_daily_true=float(kc_daily[i]),
            thick_frac=float(thick_frac[i]), clear_frac=float(clear_frac[i]),
        ))
    return out, dates, kc_daily, sun


def main():
    cfg.ensure_dirs()
    os.makedirs(REP_DIR, exist_ok=True)
    log("GenerativeAURORA v2 - dataset construction  ", datetime.now().isoformat(timespec="seconds"))
    if not os.path.exists(IN_PARQUET):
        sys.exit(f"{IN_PARQUET} not found - run 3_quality_control.py first")

    df = pd.read_parquet(IN_PARQUET)
    meta = pd.read_csv(SITE_META_CSV).set_index("site_id")
    sites = [s for s in meta.index if s in set(df.site_id)]

    wcols = {}
    for k, cands in WEATHER_CANDIDATES.items():
        hit = next((c for c in cands if c in df.columns), None)
        if hit:
            wcols[k] = hit
    section("1. INPUTS")
    log(f"rows {len(df):,}, sites {len(sites)}")
    log(f"weather columns used: {wcols}")
    missing_w = [k for k in WEATHER_CANDIDATES if k not in wcols]
    if missing_w:
        log(f"not found (skipped): {missing_w}")
    log(f"available parquet columns: {list(df.columns)}")

    # daylight outside the 05-20 window?
    hr = df["time"].dt.hour
    out_win = ((df.solar_zenith_angle < ZENITH_MAX) & ~hr.isin(HOURS)).sum()
    log(f"sun-up hours outside 05:00-20:00 window: {out_win} (must be 0)")

    # ---------------------------------------------------------------- build
    recs, site_of, clim = [], [], {}
    hours_total = hours_excl = 0
    for sid in sites:
        g = df[df.site_id == sid].sort_values("time")
        m = meta.loc[sid]
        out, dates, kc_daily, sun = build_site(g, m, wcols)
        # site k_c climatology by month, TRAINING years of the main split only
        dd = pd.Series(kc_daily, index=pd.to_datetime(dates))
        for key, years in (("main", cfg.TRAIN_YEARS), ("alt", [2016, 2017])):
            tr = dd[dd.index.year.isin(years)]
            mon = tr.groupby(tr.index.month).mean().reindex(range(1, 13))
            clim.setdefault(key, {})[sid] = mon.fillna(tr.mean()).values
        for r in out:
            recs.append(r); site_of.append(sid)
        gg = g[(g.time.dt.hour.isin(HOURS)) & (g.solar_zenith_angle < ZENITH_MAX) &
               (g.clearsky_ghi > CLEARSKY_MIN)]
        hours_total += len(gg)
        hours_excl += int(gg.fill_flag.isin(TARGET_EXCLUDE_FILL).sum())
        print(f"  {sid}: {len(out)} samples", end="\r")

    N = len(recs)
    p_names = list(recs[0]["past"].keys())
    f_names = list(recs[0]["fut"].keys())
    x_past = np.stack([np.stack([r["past"][k] for k in p_names], -1) for r in recs]).astype(np.float32)
    x_fut = np.stack([np.stack([r["fut"][k] for k in f_names], -1) for r in recs]).astype(np.float32)
    x_hist = np.stack([r["hist"] for r in recs]).astype(np.float32)
    y = np.stack([r["y"] for r in recs]).astype(np.float32)
    m_y = np.stack([r["m_y"] for r in recs]).astype(np.float32)
    cs = np.stack([r["cs"] for r in recs]).astype(np.float32)
    ghi = np.stack([r["ghi"] for r in recs]).astype(np.float32)
    dates = np.array([r["date"].isoformat() for r in recs])
    d_obj = [r["date"] for r in recs]
    site_id = np.array(site_of)
    regime_true = np.array([r["regime_true"] for r in recs], dtype=np.int8)
    regime_proxy = np.array([r["regime_proxy"] for r in recs], dtype=np.int8)
    split_main = np.array([cfg.split_of(d) for d in d_obj])
    split_alt_ = np.array([split_alt(d) for d in d_obj])

    s_names = ["lat", "lon", "elevation_km"] + [f"clim_kc_m{m:02d}" for m in range(1, 13)]
    def static_for(key):
        return {sid: np.r_[meta.loc[sid, "ret_lat"], meta.loc[sid, "ret_lon"],
                           meta.loc[sid, "elevation_m"] / 1000.0, clim[key][sid]] for sid in sites}
    st, st_alt = static_for("main"), static_for("alt")
    x_static = np.stack([st[s] for s in site_of]).astype(np.float32)          # climatology 2016-18
    x_static_alt = np.stack([st_alt[s] for s in site_of]).astype(np.float32)  # climatology 2016-17
    region = np.array([meta.loc[s, "region"] for s in site_of])

    # ---------------------------------------------------------------- normalise
    norm_mask = np.isin([d.year for d in d_obj], NORM_YEARS)
    norm = {"past": {}, "hist": {}, "static": {}}
    skip_past = {"kc", "valid_past", "filled_past", "cos_zenith"} | set(CLOUD_GROUPS)
    for k_i, k in enumerate(p_names):
        if k in skip_past:
            continue
        sel = x_past[norm_mask, :, k_i]
        mu, sd = float(np.nanmean(sel)), float(np.nanstd(sel) or 1.0)
        x_past[:, :, k_i] = (x_past[:, :, k_i] - mu) / sd
        norm["past"][k] = [mu, sd]
    # history: missing days -> training mean
    hmu = float(np.nanmean(x_hist[norm_mask]))
    m_hist = (~np.isnan(x_hist)).astype(np.float32)      # 0 = day missing (no valid hours)
    x_hist = np.where(np.isnan(x_hist), hmu, x_hist)
    norm["hist"]["fill_value"] = hmu
    # Fixed physical scaling (no statistics from any split or region, so held-out
    # regions cannot influence preprocessing): lat/10, (lon-118)/15, elevation km
    fixed = {"lat": (0.0, 10.0), "lon": (118.0, 15.0), "elevation_km": (0.0, 1.0)}
    for k_i, k in enumerate(s_names[:3]):
        mu, sd = fixed[k]
        x_static[:, k_i] = (x_static[:, k_i] - mu) / sd
        x_static_alt[:, k_i] = (x_static_alt[:, k_i] - mu) / sd
        norm["static"][k] = [mu, sd]
    x_past = np.nan_to_num(x_past)

    # ---------------------------------------------------------------- report
    section("2. SAMPLES")
    log(f"samples (site-days): {N:,}  shape x_past {x_past.shape}, x_future {x_fut.shape}, "
        f"x_hist {x_hist.shape}, x_static {x_static.shape}, y {y.shape}")
    for name, sp in [("split_main", split_main), ("split_alt", split_alt_)]:
        u, c = np.unique(sp, return_counts=True)
        log(f"{name}: " + ", ".join(f"{a}={b}" for a, b in zip(u, c)))
    log(f"target hours excluded by fill flags {TARGET_EXCLUDE_FILL}: "
        f"{hours_excl:,} of {hours_total:,} sun-up hours ({100 * hours_excl / hours_total:.1f}%)")
    log(f"missing days in 7-day history: {100 * (1 - m_hist.mean()):.2f}% (filled with "
        f"training mean, flagged in m_hist)")
    log(f"valid target hours per sample: mean {m_y.sum(1).mean():.1f}, "
        f"min {int(m_y.sum(1).min())}, max {int(m_y.sum(1).max())} of {len(HOURS)}")
    log(f"masked (non-target) positions: {100 * (1 - m_y.mean()):.1f}% "
        "(night + excluded; ignored by loss & metrics)")
    kv = y[m_y > 0]
    log(f"k_c target over valid hours: mean {kv.mean():.3f}, q10 {np.quantile(kv, .1):.3f}, "
        f"q50 {np.quantile(kv, .5):.3f}, q90 {np.quantile(kv, .9):.3f}, max {kv.max():.3f}")

    section("3. REALISED SKY REGIMES (" + ("satellite cloud classes" if USE_CLOUD_FEATURES
            else "daily mean k_c: Clear >= 0.85, Overcast <= 0.40") + ", day D; evaluation only)")
    for sp in ["train", "val", "cal", "test"]:
        s = split_main == sp
        u = np.bincount(regime_true[s], minlength=3)
        log(f"{sp:5s}: " + ", ".join(f"{REGIMES[i]}={u[i]} ({100 * u[i] / max(s.sum(), 1):.1f}%)"
                                     for i in range(3)))
    agree = (regime_true == regime_proxy).mean() * 100
    always = 100 * np.bincount(regime_true).max() / N
    log(f"previous-day proxy agreement {agree:.1f}% vs. 'always majority class' {always:.1f}% "
        f"-> proxy {'has' if agree > always + 2 else 'has NO'} real skill")
    # sanity: does regime match k_c?
    for i in range(3):
        s = regime_true == i
        if s.any():
            log(f"  mean k_c on {REGIMES[i]:8s} days: {np.nanmean([r['kc_daily_true'] for r, ss in zip(recs, s) if ss]):.3f}")

    section("3b. YEAR-BY-YEAR: weather variability or cloud-classification change?")
    yrs = np.array([d.year for d in d_obj])
    kcd = np.array([r["kc_daily_true"] for r in recs])
    thk = np.array([r["thick_frac"] for r in recs])
    clr = np.array([r["clear_frac"] for r in recs])
    rows = []
    log(f"{'year':6s}{'thick-cloud hrs':>16s}{'clear hrs':>11s}{'Overcast days':>15s}"
        f"{'mean k_c':>10s}{'k_c Overcast':>14s}{'k_c q10 (days)':>16s}")
    for yr in sorted(set(yrs)):
        s_ = yrs == yr
        ov = regime_true[s_] == 2
        rows.append((yr, thk[s_].mean(), ov.mean(), np.nanmean(kcd[s_])))
        log(f"{yr:<6d}{100 * thk[s_].mean():15.1f}%{100 * clr[s_].mean():10.1f}%"
            f"{100 * ov.mean():14.1f}%{np.nanmean(kcd[s_]):10.3f}"
            f"{(np.nanmean(kcd[s_][ov]) if ov.any() else float('nan')):14.3f}"
            f"{np.nanquantile(kcd[s_], 0.1):16.3f}")
    old = [r for r in rows if r[0] < 2020]
    new = [r for r in rows if r[0] == 2020]
    if new and len(old) >= 3:
        thk_old = np.array([r[1] for r in old]); kc_old = np.array([r[3] for r in old])
        z_thk = (new[0][1] - thk_old.mean()) / (thk_old.std(ddof=1) or 1e-9)
        z_kc = (new[0][3] - kc_old.mean()) / (kc_old.std(ddof=1) or 1e-9)
        log(f"2020 vs 2016-19: thick-cloud share z = {z_thk:+.1f}, mean k_c z = {z_kc:+.1f}")
        if abs(z_thk) > 3 and abs(z_kc) < 2:
            log("-> cloud CLASSES shifted but irradiance did not: suspected cloud-classification "
                "discontinuity in 2020 (year and version label are confounded). " +
                ("Already handled: cloud features are OFF." if not USE_CLOUD_FEATURES
                 else "Set USE_CLOUD_FEATURES = False and rerun."))
        elif abs(z_thk) > 3:
            log("-> clouds AND irradiance shifted together: consistent with real weather (e.g. La Nina "
                "2020). Keep cloud features; report 2020 as a cloudier test year.")
        else:
            log("-> no unusual shift in cloud classes in 2020.")
    log(f"cloud features in inputs: {USE_CLOUD_FEATURES}")
    log("\nInput variables, daytime mean per year (all sites) and z of 2020 vs 2016-19:")
    dfd = df[df.solar_zenith_angle < ZENITH_MAX]
    yy = dfd["time"].dt.year
    for k, c in [("ghi", "ghi"), ("dni", "dni"), ("dhi", "dhi")] + list(wcols.items()):
        mv = dfd.groupby(yy)[c].mean()
        o = mv[mv.index < 2020]
        z = (mv.get(2020, np.nan) - o.mean()) / (o.std(ddof=1) or 1e-9)
        flag = "  <-- check" if abs(z) > 3 else ""
        log(f"  {k:20s} " + " ".join(f"{v:9.3f}" for v in mv.values) + f"   z={z:+.1f}{flag}")

    section("4. SITES AND REGIONS")
    for reg in sorted(set(region)):
        sids = sorted(set(site_id[region == reg]))
        log(f"{reg:14s} {len(sids)} sites, {int((region == reg).sum()):,} samples")
    log("x_static per site (lat, lon, elev km, mean monthly k_c 2016-18; alt split uses 2016-17):")
    for sid in sites:
        v = st[sid]
        log(f"  {sid}: {v[0]:7.2f} {v[1]:8.2f} {v[2]:6.3f}  clim k_c {np.mean(v[3:]):.3f}")

    section("5. LEAKAGE CHECKS")
    # x_past must be day D-1: its k_c channel must NOT equal the target
    k_i = p_names.index("kc")
    ident = np.all(np.isclose(x_past[:, :, k_i] * m_y, y * m_y, atol=1e-6), axis=1) & (m_y.sum(1) > 0)
    # identity is tested on the target-valid hours, so "clear" must be judged there too
    all_clear = np.all((y >= 0.999) | (m_y == 0), axis=1)
    log(f"identical past/target k_c because BOTH days are fully clear (k_c capped at 1.0): "
        f"{100 * np.mean(ident & all_clear):.2f}%  (expected, not leakage)")
    same = np.mean(ident & ~all_clear)
    corr = np.corrcoef(x_past[:, :, k_i][m_y > 0], y[m_y > 0])[0, 1]
    log(f"identical past/target k_c on NON-clear days: {100 * same:.3f}%  (must be ~0)")
    log(f"corr(past k_c, target k_c) on valid hours: {corr:.3f}  (day-to-day persistence; "
        "~1.0 would mean leakage)")
    log("x_future contains only: " + ", ".join(f_names) + "  (deterministic sun geometry)")
    log("site ID is not a model input (x_static has coordinates + climatology only)")
    log("climatology: x_static from 2016-18 (main split), x_static_alt from 2016-17 (alt split)")
    log("coordinates use fixed physical scaling: no statistics from any split or region")

    # ---------------------------------------------------------------- save
    section("6. OUTPUT")
    np.savez_compressed(
        OUT_NPZ, x_past=x_past, x_future=x_fut, x_hist=x_hist, m_hist=m_hist,
        x_static=x_static, x_static_alt=x_static_alt,
        y=y, m_y=m_y, clearsky=cs, ghi=ghi, date=dates, site_id=site_id, region=region,
        split_main=split_main, split_alt=split_alt_,
        regime_true=regime_true, regime_proxy=regime_proxy)
    info = dict(
        created=datetime.now().isoformat(timespec="seconds"),
        hours=HOURS, zenith_max=ZENITH_MAX, clearsky_min=CLEARSKY_MIN,
        target_exclude_fill=TARGET_EXCLUDE_FILL, use_cloud_features=USE_CLOUD_FEATURES, min_valid_target_hours=MIN_VALID_TARGET_HOURS,
        hist_days=HIST_DAYS, norm_years=NORM_YEARS, regimes=REGIMES,
        regime_rule=(dict(source="satellite_cloud_type", clear_fraction_min=REGIME_CLEAR_MIN,
                          overcast_fraction_min=REGIME_OVERCAST_MIN, cloud_groups=CLOUD_GROUPS)
                     if USE_CLOUD_FEATURES else
                     dict(source="daily_mean_valid_kc", clear_kc_min=REGIME_KC_CLEAR,
                          overcast_kc_max=REGIME_KC_OVERCAST)),
        past_features=p_names, future_features=f_names, static_features=s_names,
        weather_columns=wcols, normalisation=norm,
        target="clear-sky index k_c = GHI / clear-sky GHI on day D, masked by m_y",
    )
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2)
    log(f"{OUT_NPZ}  ({os.path.getsize(OUT_NPZ) / 1e6:.1f} MB)")
    log(f"{OUT_JSON}")
    with open(REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(_lines))
    print(f"\nReport saved: {REPORT}  -> send this file to Claude")


if __name__ == "__main__":
    main()