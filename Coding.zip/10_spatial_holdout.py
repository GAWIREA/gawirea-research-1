"""
GenerativeAURORA v2 - 10_spatial_holdout.py
===========================================
Does GenerativeAURORA work in parts of Indonesia it has NEVER seen?

Leave-one-region-out: for each of the 7 regions (Sumatra, Java, Kalimantan,
Sulawesi, Nusa_Tenggara, Maluku, Papua):
  1. Train GenerativeAURORA (tuned settings) and the strongest baseline,
     Transformer-QR (its own tuned learning rate), WITHOUT any data from that
     region: training AND early-stopping validation use the other 6 regions only.
  2. Calibrate (point-mass snap + Mondrian conformal) on the 'cal' days of the
     6 TRAINING regions only: no local calibration data from the new region.
  3. Forecast the held-out region and score it.

Two deployment settings for the held-out sites (same trained model):
  local     the new site's own monthly k_c climatology from 2016-2018
            satellite data (Himawari covers all of Indonesia, so any new site
            has this history) -> "transfer with local satellite history"
  zeroshot  that climatology is replaced by the average of the training
            sites -> nothing site-specific except coordinates and elevation

Reference rows for the same held-out days
  indomain  the main GenerativeAURORA (main_tuned, trained on ALL regions):
            the generalisation gap = holdout vs indomain
  CLIM      climatology of the site (standard reference)

Default evaluation split is 'val' (2019 odd weeks); the test year 2020 stays
closed. Run with --target test only once, at the very end.

Usage
    python 10_spatial_holdout.py                  # 7 regions x 3 seeds (~5-6 h)
    python 10_spatial_holdout.py --seeds 0        # quicker: 1 seed (~2 h)
    python 10_spatial_holdout.py --regions Papua,Java
    python 10_spatial_holdout.py --report         # only rebuild the tables
    python 10_spatial_holdout.py --ga-base-ch 24  # same experiment with the small (1.24M) model
    python 10_spatial_holdout.py --rescore-indomain   # redo only the in-domain rows (minutes)

Limitation (state in the paper): hyperparameters were tuned once on the validation
split of all regions and then fixed; they are not re-tuned inside each fold.
The tuning search showed low sensitivity (val CRPS 0.1199-0.1240 over 30 trials).
Resumable: finished trainings and scenario files are skipped.
"""

import os
import sys
import json
import time
import argparse
import importlib
from datetime import datetime

import numpy as np
import pandas as pd
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
cfg = importlib.import_module("1_config")
M = importlib.import_module("5_model")
TR = importlib.import_module("6_train")
C = importlib.import_module("7_calibrate")
E = importlib.import_module("8_evaluate")
B = importlib.import_module("9_baselines")

OUT_DIR = os.path.join(cfg.RESULT_DIR, "spatial")
SCEN_DIR = os.path.join(cfg.RESULT_DIR, "scenarios", "spatial")
K = 100
STEPS = 50
CLIM_COLS = slice(3, 15)     # x_static: lat, lon, elev, 12 monthly k_c climatology values
MODELS = {"GenerativeAURORA": "ga", "TransformerQR": "tqr"}
GA_BASE_CH = None          # set by --ga-base-ch (e.g. 24 = parameter-matched model)
IND_RUN = "main_tuned"     # in-domain reference run (main_small for the small model)
TAG = ""                   # suffix for result files


# ----------------------------------------------------------------------------
def tuned_settings():
    p = os.path.join(cfg.RESULT_DIR, "tuning", "main_best_params.json")
    if not os.path.exists(p):
        sys.exit("Results/tuning/main_best_params.json not found (run 6_train.py --tune first)")
    best = json.load(open(p))["best_params"]
    mc_p, tc_p = TR.split_params(best)
    mc_ga, tc_ga = dict(M.MODEL_CFG, **mc_p), dict(TR.TRAIN_CFG, **tc_p)
    if GA_BASE_CH:
        mc_ga["base_ch"] = GA_BASE_CH
    lr_file = os.path.join(cfg.RESULT_DIR, "baselines", "base_transqr_lr_search.json")
    lr_b = json.load(open(lr_file))["best_lr"] if os.path.exists(lr_file) else TR.TRAIN_CFG["lr"]
    tc_b = dict(TR.TRAIN_CFG, lr=lr_b)
    for k in ("weight_decay", "batch_size"):
        if k in best:
            tc_b[k] = best[k]
    mc_b = {"dropout": float(best.get("dropout", B.ENC_DROPOUT))}
    return mc_ga, tc_ga, mc_b, tc_b


def run_dir(region, model_key, seed):
    return os.path.join(cfg.CKPT_DIR, f"holdout_{region}", model_key, f"seed{seed}")


def train(data, info, region, model_key, seed, held_sites, settings):
    rd = run_dir(region, model_key, seed)
    if os.path.exists(os.path.join(rd, "summary.json")):
        print(f"  [{region} {model_key} seed {seed}] already trained - skipping")
        return
    mc_ga, tc_ga, mc_b, tc_b = settings
    t0 = time.time()
    if model_key.startswith("ga"):
        s = TR.train_one(data, info, "main", seed, mc_ga, tc_ga, rd, exclude_sites=held_sites,
                         log_prefix=f"[{region} GA s{seed}] ", quiet=True)
    else:
        s = TR.train_one(data, info, "main", seed, mc_b, tc_b, rd, exclude_sites=held_sites,
                         log_prefix=f"[{region} TQR s{seed}] ", quiet=True,
                         model_fn=lambda d, mc: B.TransQR(d, mc))
    print(f"  [{region} {model_key} seed {seed}] val CRPS (6 training regions) "
          f"{s['best_val_crps']:.4f} at epoch {s['best_epoch']} ({(time.time() - t0) / 60:.1f} min)")


@torch.no_grad()
def generate(region, model_key, seed, d, tag):
    path = os.path.join(SCEN_DIR, region, model_key, f"seed{seed}_{tag}.npz")
    if os.path.exists(path):
        return dict(np.load(path, allow_pickle=True))
    ck = torch.load(os.path.join(run_dir(region, model_key, seed), "best.pt"),
                    map_location="cpu", weights_only=False)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cls = M.GenerativeAURORA if model_key.startswith("ga") else B.TransQR
    model = cls(ck["dims"], ck["mc"]).to(dev)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    g = torch.Generator(device=dev).manual_seed(20_000 + seed)
    out = []
    bs = max(1, 12_800 // K)
    for s in range(0, len(d["y"]), bs):
        b = M.to_batch(d, np.arange(s, min(s + bs, len(d["y"]))), dev)
        out.append(model.sample(b, K=K, steps=STEPS, generator=g).cpu().numpy().astype(np.float16))
    sc = dict(S=np.concatenate(out), y=d["y"], m_y=d["m_y"], clearsky=d["clearsky"],
              date=d["date"], site_id=d["site_id"], region=d["region"],
              regime_true=d["regime_true"], regime_proxy=d["regime_proxy"])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path, **sc)
    return sc


def zeroshot(d, train_static):
    """Replace the held-out sites' climatology by the training-site average."""
    d = dict(d)
    xs = d["x_static"].copy()
    xs[:, CLIM_COLS] = train_static[:, CLIM_COLS].mean(0)
    d["x_static"] = xs
    return d


# ----------------------------------------------------------------------------
def score_ensemble(S, y, m, cs):
    w = m.sum(1)
    def wavg(a):
        return float((a * w).sum() / max(w.sum(), 1))
    return dict(crps_kc=wavg(E.crps_days(S, y, m)),
                crps_wm2=wavg(E.crps_days(S * cs[:, None, :], y * cs, m)),
                energy=float(E.energy_days(S, y, m).mean()),
                variogram=float(E.variogram_days(S, y, m).mean()))


def calibrated(cal, test):
    """Point-mass snap + Mondrian 90% fitted on `cal`, scored on `test`."""
    cal, test = dict(cal), dict(test)
    delta, _ = C.fit_snap(cal)
    cal["S"], test["S"] = C.snap(cal["S"], delta), C.snap(test["S"], delta)
    q = C.fit(cal, 0.90)
    L, U = C.apply(test, 0.90, q, "mondrian")
    r = C.score(test, L, U, level=0.90)
    return test["S"], dict(cov90=r["coverage"], width_wm2=r["width_wm2"], int_score=r["interval_score"])


def evaluate_region(data, region, seed, target, held_sites, rows_held, clim_S):
    out = []
    y = data["y"][rows_held].astype(np.float32)
    m = data["m_y"][rows_held].astype(np.float32)
    cs = data["clearsky"][rows_held].astype(np.float32)

    # CLIM reference
    out.append(dict(region=region, seed=seed, model="CLIM", setting="-",
                    **score_ensemble(clim_S, y, m, cs)))

    # held-out models, calibrated on the training regions' cal days
    tr_cal = M.load_split(data, "cal", "main", exclude_sites=held_sites)
    held = M.load_split(data, target, "main", sites=held_sites)
    tr_static = M.load_split(data, "train", "main", exclude_sites=held_sites)["x_static"]
    for name, key in MODELS.items():
        cal_sc = generate(region, key, seed, tr_cal, "cal_trainregions")
        for setting, d in [("local", held), ("zeroshot", zeroshot(held, tr_static))]:
            sc = generate(region, key, seed, d, f"{target}_{setting}")
            S, cal_r = calibrated(cal_sc, sc)
            out.append(dict(region=region, seed=seed, model=name, setting=setting,
                            **score_ensemble(S, y, m, cs), **cal_r))

    r = indomain_row(data, region, seed, target, held_sites, rows_held)
    if r:
        out.append(r)
    return out


def indomain_row(data, region, seed, target, held_sites, rows_held):
    """In-domain reference (trained with ALL regions), scored on the same held-out
    days. Its calibration uses the SAME 6 training regions' cal days as the
    held-out models, so the gap measures only the effect of excluding the region
    from training."""
    y = data["y"][rows_held].astype(np.float32)
    m = data["m_y"][rows_held].astype(np.float32)
    cs = data["clearsky"][rows_held].astype(np.float32)
    p_t = os.path.join(cfg.RESULT_DIR, "scenarios", IND_RUN, f"seed{seed}_{target}.npz")
    p_c = os.path.join(cfg.RESULT_DIR, "scenarios", IND_RUN, f"seed{seed}_cal.npz")
    if not (os.path.exists(p_t) and os.path.exists(p_c)):
        print(f"  (no {IND_RUN} seed{seed} '{target}' scenarios: in-domain row skipped; "
              f"run 7_calibrate.py --run {IND_RUN}{' --target test' if target == 'test' else ''})")
        return None

    def subset(d, sel):
        return {k: (v[sel] if isinstance(v, np.ndarray) and v.ndim and len(v) == len(sel) else v)
                for k, v in d.items()}
    full = dict(np.load(p_t, allow_pickle=True))
    sub = subset(full, np.isin(full["site_id"], list(held_sites)))
    if not np.array_equal(sub["date"], data["date"][rows_held]):
        print("  !! in-domain scenario order differs - skipping in-domain row")
        return None
    cal_full = dict(np.load(p_c, allow_pickle=True))
    cal_tr = subset(cal_full, ~np.isin(cal_full["site_id"], list(held_sites)))
    S, cal_r = calibrated(cal_tr, sub)
    return dict(region=region, seed=seed, model="GenerativeAURORA", setting="indomain",
                **score_ensemble(S, y, m, cs), **cal_r)


# ----------------------------------------------------------------------------
def report(target):
    p = os.path.join(OUT_DIR, f"spatial_{target}{TAG}_raw.csv")
    if not os.path.exists(p):
        sys.exit("no results yet")
    df = pd.read_csv(p)
    clim = df[df.model == "CLIM"].set_index(["region", "seed"])["crps_kc"]
    df["crpss_vs_CLIM"] = 1 - df["crps_kc"] / df.set_index(["region", "seed"]).index.map(clim).values
    cols = ["crps_kc", "crps_wm2", "crpss_vs_CLIM", "energy", "variogram", "cov90", "width_wm2", "int_score"]
    lines = [f"GenerativeAURORA v2 - leave-one-region-out ({target}{TAG}; GenerativeAURORA "
             f"{'base_ch ' + str(GA_BASE_CH) if GA_BASE_CH else 'tuned (base_ch 96)'}, in-domain = {IND_RUN})  "
             f"{datetime.now().isoformat(timespec='seconds')}",
             f"seeds: {sorted(df.seed.unique().tolist())}; calibration fitted on the 6 TRAINING regions only",
             "settings: indomain = trained with all regions; local = region never seen, own satellite "
             "climatology; zeroshot = region never seen, climatology replaced by training-site average"]
    order = [("GenerativeAURORA", "indomain"), ("GenerativeAURORA", "local"),
             ("GenerativeAURORA", "zeroshot"), ("TransformerQR", "local"),
             ("TransformerQR", "zeroshot"), ("CLIM", "-")]
    for region in sorted(df.region.unique()):
        lines.append(f"\n--- held-out region: {region}")
        g = df[df.region == region].groupby(["model", "setting"])[cols].mean()
        g = g.reindex([o for o in order if o in g.index])
        lines.append(g.round(4).to_string())
    sd = df[df.setting.isin(["local", "indomain"])].groupby(["region", "model", "setting"])["crps_kc"].std()
    lines.append("\nseed-to-seed std of CRPS per region (stability):")
    lines.append(sd.unstack(["model", "setting"]).round(4).to_string())
    lines.append("\n=== MEAN OVER ALL HELD-OUT REGIONS (and seeds) ===")
    g = df.groupby(["model", "setting"])[cols].mean()
    g = g.reindex([o for o in order if o in g.index])
    lines.append(g.round(4).to_string())

    ga = df[df.model == "GenerativeAURORA"].pivot_table(index=["region", "seed"], columns="setting",
                                                        values="crps_kc")
    if {"indomain", "local"} <= set(ga.columns):
        gap = 100 * (ga["local"] / ga["indomain"] - 1)
        lines.append(f"\ngeneralisation gap (CRPS, never-seen region vs trained-with-region): "
                     f"{gap.mean():+.2f}% (range {gap.min():+.2f}% to {gap.max():+.2f}%)")
    if {"local", "zeroshot"} <= set(ga.columns):
        z = 100 * (ga["zeroshot"] / ga["local"] - 1)
        lines.append(f"cost of having NO local climatology (zeroshot vs local): {z.mean():+.2f}%")
    t = df[df.setting == "local"].pivot_table(index=["region", "seed"], columns="model",
                                              values=["energy", "variogram", "crps_kc"])
    if ("energy", "TransformerQR") in t.columns:
        for met in ["crps_kc", "energy", "variogram"]:
            d = 100 * (1 - t[(met, "GenerativeAURORA")] / t[(met, "TransformerQR")])
            wins = int((d > 0).sum())
            lines.append(f"GenerativeAURORA vs Transformer-QR in unseen regions, {met}: "
                         f"{d.mean():+.1f}% better on average, better in {wins}/{len(d)} region-seeds")
    txt = "\n".join(lines)
    print("\n" + txt)
    df.to_csv(os.path.join(OUT_DIR, f"spatial_{target}{TAG}_scored.csv"), index=False)
    rp = os.path.join(OUT_DIR, f"spatial_{target}{TAG}_report.txt")
    with open(rp, "w", encoding="utf-8") as f:
        f.write(txt)
    print(f"\nReport saved: {rp}  -> send this file to Claude")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--regions", default="")
    ap.add_argument("--seeds", default="0,1,2")
    ap.add_argument("--target", default="val", choices=["val", "test"])
    ap.add_argument("--report", action="store_true", help="only rebuild the report")
    ap.add_argument("--rescore-indomain", action="store_true",
                    help="recompute only the in-domain rows (calibrated on the 6 training regions)")
    ap.add_argument("--ga-base-ch", type=int, help="U-Net width of GenerativeAURORA (24 = small model)")
    ap.add_argument("--indomain-run", default=None, help="in-domain reference run (default main_tuned, "
                    "or main_small when --ga-base-ch is given)")
    args = ap.parse_args()
    global GA_BASE_CH, IND_RUN, TAG
    if args.ga_base_ch:
        GA_BASE_CH = args.ga_base_ch
        MODELS["GenerativeAURORA"] = f"ga_bc{GA_BASE_CH}"
        TAG = f"_bc{GA_BASE_CH}"
        IND_RUN = args.indomain_run or "main_small"
    elif args.indomain_run:
        IND_RUN = args.indomain_run
    os.makedirs(OUT_DIR, exist_ok=True)
    if args.report:
        report(args.target)
        return

    data = dict(np.load(M.DATA_NPZ, allow_pickle=True))
    info = M.load_info()
    regions = [r for r in args.regions.split(",") if r] or sorted(np.unique(data["region"]).tolist())
    seeds = [int(s) for s in args.seeds.split(",")]
    settings = tuned_settings()
    key = "split_main"
    print(f"device: {'cuda ' + torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
    print(f"regions {regions}, seeds {seeds}, evaluation split '{args.target}'")
    if args.target == "test":
        print("!! TEST SET: use only once, with the frozen protocol")

    raw_path = os.path.join(OUT_DIR, f"spatial_{args.target}{TAG}_raw.csv")
    done = pd.read_csv(raw_path) if os.path.exists(raw_path) else pd.DataFrame()
    if args.rescore_indomain:
        if done.empty:
            sys.exit(f"{raw_path} not found")
        done = done[done.setting != "indomain"]
        new = []
        for region in regions:
            held_sites = set(data["site_id"][data["region"] == region])
            rows_held = np.where((data[key] == args.target) & np.isin(data["site_id"], list(held_sites)))[0]
            for seed in sorted(done[done.region == region].seed.unique()):
                r = indomain_row(data, region, int(seed), args.target, held_sites, rows_held)
                if r:
                    new.append(r)
                    print(f"  {region} seed {seed}: in-domain CRPS {r['crps_kc']:.4f}, cov90 {r['cov90']:.1f}%")
        done = pd.concat([done, pd.DataFrame(new)], ignore_index=True)
        done.to_csv(raw_path, index=False)
        report(args.target)
        return
    t_start = time.time()
    for region in regions:
        held_sites = set(data["site_id"][data["region"] == region])
        rows_held = np.where((data[key] == args.target) & np.isin(data["site_id"], list(held_sites)))[0]
        print(f"\n######## held-out region {region}: {len(held_sites)} sites, "
              f"{len(rows_held)} evaluation days")
        for seed in seeds:
            if len(done) and ((done.region == region) & (done.seed == seed)).any():
                print(f"  [{region} seed {seed}] already evaluated - skipping")
                continue
            for mk in MODELS.values():
                train(data, info, region, mk, seed, held_sites, settings)
            clim_S = E.climatology(data, "main", rows_held, K, seed)
            rows = evaluate_region(data, region, seed, args.target, held_sites, rows_held, clim_S)
            done = pd.concat([done, pd.DataFrame(rows)], ignore_index=True)
            done.to_csv(raw_path, index=False)
            ga = [r for r in rows if r["model"] == "GenerativeAURORA"]
            print("  " + "  ".join(f"{r['setting']}: CRPS {r['crps_kc']:.4f} energy {r['energy']:.4f}"
                                   for r in ga))
            print(f"  elapsed {(time.time() - t_start) / 3600:.2f} h")
    report(args.target)


if __name__ == "__main__":
    main()