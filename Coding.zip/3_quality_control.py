"""
GenerativeAURORA v2 - 3_quality_control.py
==========================================
Reads every raw Himawari CSV, checks it, and writes ONE combined, flagged
dataset. Nothing is deleted: bad values get a flag column, and script 4
decides what to use.

Checks
  1. Completeness   : rows per year, duplicate / missing timestamps, NaNs
  2. Time convention: recomputes the sun position and finds which minute
                      offset the 'Solar Zenith Angle' column refers to
                      (instant at :00, centre of the hour at :30, ...).
                      This decides how GHI and clear-sky GHI line up.
  3. Physics        : negative GHI, GHI at night, GHI far above clear sky,
                      DHI > GHI, closure GHI ~ DNI*cos(z) + DHI
  4. NSRDB flags    : fill_flag (gap-filled values) and cloud_type codes,
                      decoded with the labels in each file's own header
  5. Version check  : 2016-2019 files say Version=unknown, 2020 says 3.1.1.
                      Compares 2020 against the 2016-2019 spread for each
                      site. If 2020 jumps far outside the normal year-to-year
                      variation, the test year is not comparable.

Outputs
  Dataset/processed/himawari_qc.parquet   all sites, hourly, with qc_* flags
  Dataset/metadata/site_meta.csv          returned pixel lat/lon/elev/TZ
  Results/qc/qc_summary.csv               one row per site-year
  Results/qc/qc_report.txt                human-readable report (send to Claude)

Usage:
    python 3_quality_control.py
"""

import os
import sys
import csv
import glob
import importlib
from datetime import datetime

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
cfg = importlib.import_module("1_config")

QC_DIR = os.path.join(cfg.RESULT_DIR, "qc")
OUT_PARQUET = os.path.join(cfg.PROC_DIR, "himawari_qc.parquet")
SITE_META_CSV = os.path.join(cfg.META_DIR, "site_meta.csv")
SUMMARY_CSV = os.path.join(QC_DIR, "qc_summary.csv")
REPORT_TXT = os.path.join(QC_DIR, "qc_report.txt")

_lines = []


def log(*a):
    s = " ".join(str(x) for x in a)
    print(s)
    _lines.append(s)


def section(t):
    log("\n" + "=" * 78)
    log(t)
    log("=" * 78)


# ----------------------------------------------------------------------------
# Reading
# ----------------------------------------------------------------------------
def snake(name):
    return (name.strip().lower().replace(" ", "_").replace("(", "").replace(")", "")
            .replace("/", "_"))


def read_raw(path):
    with open(path, encoding="utf-8-sig") as f:
        k = next(csv.reader([f.readline()]))
        v = next(csv.reader([f.readline()]))
    meta = dict(zip([x.strip() for x in k], [x.strip() for x in v]))
    df = pd.read_csv(path, skiprows=2, encoding="utf-8-sig")
    df.columns = [snake(c) for c in df.columns]
    # code -> label maps stored in the header ("Cloud Type 0" -> "Clear")
    ct = {int(kk.split()[-1]): vv for kk, vv in meta.items()
          if kk.startswith("Cloud Type ") and kk.split()[-1].lstrip("-").isdigit()}
    ff = {int(kk.split()[-1]): vv for kk, vv in meta.items()
          if kk.startswith("Fill Flag ") and kk.split()[-1].lstrip("-").isdigit()}
    return meta, df, ct, ff


# ----------------------------------------------------------------------------
# Solar position (NOAA general solar position equations; ~0.5 deg accuracy,
# enough to detect a 30-minute timestamp offset, which is ~7.5 deg)
# ----------------------------------------------------------------------------
def solar_zenith(utc_times, lat, lon):
    t = pd.DatetimeIndex(utc_times)
    doy = t.dayofyear.values
    hour = t.hour.values + t.minute.values / 60.0
    g = 2 * np.pi / 365.0 * (doy - 1 + (hour - 12) / 24)
    eot = 229.18 * (0.000075 + 0.001868 * np.cos(g) - 0.032077 * np.sin(g)
                    - 0.014615 * np.cos(2 * g) - 0.040849 * np.sin(2 * g))
    decl = (0.006918 - 0.399912 * np.cos(g) + 0.070257 * np.sin(g)
            - 0.006758 * np.cos(2 * g) + 0.000907 * np.sin(2 * g)
            - 0.002697 * np.cos(3 * g) + 0.00148 * np.sin(3 * g))
    tst = hour * 60 + eot + 4 * lon            # true solar time, minutes
    ha = np.radians(tst / 4 - 180)
    la = np.radians(lat)
    cosz = np.sin(la) * np.sin(decl) + np.cos(la) * np.cos(decl) * np.cos(ha)
    return np.degrees(np.arccos(np.clip(cosz, -1, 1)))


def hour_angle_deg(utc_times, lon):
    """Solar hour angle (deg): negative = morning, positive = afternoon."""
    t = pd.DatetimeIndex(utc_times)
    doy = t.dayofyear.values
    hour = t.hour.values + t.minute.values / 60.0
    g = 2 * np.pi / 365.0 * (doy - 1 + (hour - 12) / 24)
    eot = 229.18 * (0.000075 + 0.001868 * np.cos(g) - 0.032077 * np.sin(g)
                    - 0.014615 * np.cos(2 * g) - 0.040849 * np.sin(2 * g))
    return (hour * 60 + eot + 4 * lon) / 4 - 180


def clear_sky_symmetry(df, lat, lon, tz, offset_min, clear_codes):
    """On satellite-CLEAR hours, GHI/clear-sky GHI should be ~1 in the morning
    AND the afternoon. If GHI is an hourly average but clear-sky GHI is an
    instant (or the two are shifted in time), k_c becomes asymmetric at low sun:
    afternoon minus morning differs from 0. Returns median k_c (PM - AM) for
    |hour angle| 45-75 deg, and the median k_c of clear hours overall."""
    m = df["cloud_type"].isin(clear_codes) & (df["clearsky_ghi"] > 100)
    d = df[m]
    if len(d) < 200:
        return float("nan"), float("nan")
    utc = d["time"] - pd.to_timedelta(tz, unit="h") + pd.to_timedelta(offset_min, unit="m")
    ha = hour_angle_deg(utc, lon)
    kc = (d["ghi"] / d["clearsky_ghi"]).values
    band = (np.abs(ha) >= 45) & (np.abs(ha) <= 75)
    am, pm = kc[band & (ha < 0)], kc[band & (ha > 0)]
    if len(am) < 50 or len(pm) < 50:
        return float("nan"), float(np.median(kc))
    return float(np.median(pm) - np.median(am)), float(np.median(kc))


def detect_offset(df, lat, lon, tz):
    """Minute offset (relative to the stamped time) at which the provided
    solar zenith angle matches the computed sun position best."""
    day = df[df["solar_zenith_angle"] < 85].sample(n=min(3000, (df["solar_zenith_angle"] < 85).sum()),
                                                    random_state=0)
    utc = day["time"] - pd.to_timedelta(tz, unit="h")
    best = None
    for off in range(-60, 61, 5):
        z = solar_zenith(utc + pd.to_timedelta(off, unit="m"), lat, lon)
        rmse = float(np.sqrt(np.mean((z - day["solar_zenith_angle"].values) ** 2)))
        if best is None or rmse < best[1]:
            best = (off, rmse)
    return best


# ----------------------------------------------------------------------------
# Per-file QC
# ----------------------------------------------------------------------------
def qc_file(site_id, year, path):
    meta, df, ct_map, ff_map = read_raw(path)
    df["time"] = pd.to_datetime(dict(year=df["year"], month=df["month"], day=df["day"],
                                     hour=df["hour"], minute=df["minute"]))
    lat, lon = float(meta["Latitude"]), float(meta["Longitude"])
    tz = float(meta["Time Zone"])

    day = df["solar_zenith_angle"] < 90
    ghi, cs = df["ghi"], df["clearsky_ghi"]
    cosz = np.cos(np.radians(df["solar_zenith_angle"].clip(upper=90)))
    closure = ghi - (df["dni"] * cosz + df["dhi"])

    df["qc_ghi_negative"] = ghi < 0
    df["qc_ghi_at_night"] = (~day) & (ghi > 5)
    df["qc_ghi_above_clearsky"] = day & (cs > 50) & (ghi > 1.35 * cs + 50)
    df["qc_dhi_above_ghi"] = day & (df["dhi"] > ghi + 10)
    df["qc_closure"] = day & (df["solar_zenith_angle"] < 80) & (closure.abs() > 0.08 * ghi + 25)
    df["qc_filled"] = df["fill_flag"] > 0
    df["qc_any"] = df[[c for c in df.columns if c.startswith("qc_") and c != "qc_any"]].any(axis=1)

    n_exp = (366 if (year % 4 == 0 and cfg.LEAP_DAY) else 365) * 24 * 60 // cfg.INTERVAL_MIN
    full = pd.date_range(f"{year}-01-01", periods=n_exp, freq=f"{cfg.INTERVAL_MIN}min")
    # stamps may sit at :00 or :30, compare on the hour grid
    stamped = df["time"].dt.floor(f"{cfg.INTERVAL_MIN}min")
    missing = len(full.difference(pd.DatetimeIndex(stamped)))
    dups = int(stamped.duplicated().sum())

    off, rmse = detect_offset(df, lat, lon, tz)
    clear_codes = [c for c, lab in ct_map.items() if lab.strip().lower() == "clear"] or [0]
    asym, kc_clear = clear_sky_symmetry(df, lat, lon, tz, off, clear_codes)
    kc_day = (df["ghi"] / df["clearsky_ghi"]).where(day & (df["clearsky_ghi"] > 100)).dropna()
    meta_sig = "|".join(sorted(k for k in meta if k not in
                               ("Latitude", "Longitude", "Location ID", "Elevation",
                                "Time Zone", "Local Time Zone", "City", "State", "Country")))

    dd = df[day]
    row = dict(
        site_id=site_id, year=year, version=meta.get("Version", ""),
        n_rows=len(df), expected=n_exp, missing_stamps=missing, duplicate_stamps=dups,
        nan_cells=int(df.drop(columns=["time"]).isna().sum().sum()),
        minute_values="|".join(map(str, sorted(df["minute"].unique()))),
        sza_offset_min=off, sza_rmse_deg=round(rmse, 2),
        day_hours=int(day.sum()),
        pct_filled_day=round(100 * dd["qc_filled"].mean(), 2),
        pct_ghi_above_cs=round(100 * dd["qc_ghi_above_clearsky"].mean(), 2),
        pct_closure_fail=round(100 * dd["qc_closure"].mean(), 2),
        pct_dhi_above_ghi=round(100 * dd["qc_dhi_above_ghi"].mean(), 2),
        n_ghi_negative=int(df["qc_ghi_negative"].sum()),
        n_ghi_night=int(df["qc_ghi_at_night"].sum()),
        mean_ghi_day=round(dd["ghi"].mean(), 1),
        mean_cs_day=round(dd["clearsky_ghi"].mean(), 1),
        mean_kc_day=round((dd["ghi"] / dd["clearsky_ghi"].where(dd["clearsky_ghi"] > 50)).mean(), 3),
        kc_q10=round(float(kc_day.quantile(0.10)), 3),
        kc_q50=round(float(kc_day.quantile(0.50)), 3),
        kc_q90=round(float(kc_day.quantile(0.90)), 3),
        kc_clear_median=round(kc_clear, 3),
        kc_clear_pm_minus_am=round(asym, 3),
        n_columns=df.shape[1],
        header_signature=meta_sig,
        fill_mix="|".join(f"{int(k)}:{v:.1f}" for k, v in
                          (100 * dd["fill_flag"].value_counts(normalize=True)).sort_index().items()),
        cloud_codes="|".join(map(str, sorted(dd["cloud_type"].unique()))),
        fill_codes="|".join(map(str, sorted(df["fill_flag"].unique()))),
    )
    df["site_id"] = site_id
    meta_row = dict(site_id=site_id, year=year, ret_lat=lat, ret_lon=lon,
                    elevation_m=float(meta.get("Elevation", "nan")), tz=tz,
                    version=meta.get("Version", ""))
    return df, row, meta_row, ct_map, ff_map


# ----------------------------------------------------------------------------
def main():
    cfg.ensure_dirs()
    os.makedirs(QC_DIR, exist_ok=True)
    sites = {s["site_id"]: s for s in cfg.load_sites()}

    log("GenerativeAURORA v2 - quality control   ", datetime.now().isoformat(timespec="seconds"))
    log(f"raw folder: {cfg.RAW_DIR}")

    frames, rows, metas = [], [], []
    ct_all, ff_all = {}, {}
    missing_files = []
    for sid in sites:
        for y in cfg.YEARS:
            p = os.path.join(cfg.RAW_DIR, sid, f"{y}.csv")
            if not os.path.exists(p):
                missing_files.append(f"{sid}/{y}")
                continue
            try:
                df, row, mrow, ct, ff = qc_file(sid, y, p)
            except Exception as e:
                log(f"  !! {sid} {y}: {type(e).__name__}: {e}")
                missing_files.append(f"{sid}/{y} (unreadable)")
                continue
            frames.append(df); rows.append(row); metas.append(mrow)
            ct_all.update(ct); ff_all.update(ff)
            print(f"  {sid} {y}: ok", end="\r")

    summ = pd.DataFrame(rows)
    summ.to_csv(SUMMARY_CSV, index=False)

    # ---------------------------------------------------------------- 1
    section("1. COMPLETENESS")
    log(f"site-years read: {len(summ)} / {len(sites) * len(cfg.YEARS)}")
    if missing_files:
        log("missing/unreadable: " + ", ".join(missing_files))
    bad = summ[(summ.n_rows != summ.expected) | (summ.missing_stamps > 0) |
               (summ.duplicate_stamps > 0) | (summ.nan_cells > 0)]
    log("all site-years complete, no duplicates, no NaN" if bad.empty else
        "problems:\n" + bad[["site_id", "year", "n_rows", "expected", "missing_stamps",
                             "duplicate_stamps", "nan_cells"]].to_string(index=False))
    log(f"minute stamps: {sorted(summ.minute_values.unique())}")

    # ---------------------------------------------------------------- 2
    section("2. TIME CONVENTION (which instant does each row describe?)")
    log("offset = minutes to ADD to the stamped time so the computed sun position")
    log("matches the file's solar zenith angle. 0 = instant at the stamp,")
    log("+30 = middle of the hour after the stamp.")
    oc = summ.groupby("sza_offset_min").size()
    log("offset distribution over site-years: " + ", ".join(f"{k:+d} min: {v}" for k, v in oc.items()))
    log(f"zenith RMSE at best offset: median {summ.sza_rmse_deg.median():.2f} deg, "
        f"max {summ.sza_rmse_deg.max():.2f} deg")
    log("\nGHI vs clear-sky timing on satellite-CLEAR hours (|hour angle| 45-75 deg):")
    log("  k_c(PM) - k_c(AM) ~ 0  -> GHI and clear-sky GHI describe the same instant/interval")
    log("  |difference| > 0.05    -> timing mismatch (e.g. averages vs instants): must be")
    log("                            corrected before building the k_c target")
    sy = summ.groupby("site_id")[["kc_clear_median", "kc_clear_pm_minus_am"]].median()
    log(sy.round(3).to_string())
    bad_sym = sy[sy.kc_clear_pm_minus_am.abs() > 0.05]
    n_na = int(sy.kc_clear_pm_minus_am.isna().sum())
    log(f"  asymmetric sites: {bad_sym.index.tolist() or 'none'};  inconclusive (too few "
        f"satellite-Clear hours): {n_na}")
    if (summ.kc_clear_median.dropna() == 1.0).all():
        log("  NOTE: k_c is exactly 1.000 on every Clear hour -> the PSM sets GHI = clear-sky GHI")
        log("  for clear pixels at the SAME instant. Together with the zenith offset of 0 min,")
        log("  this means rows are instantaneous values at the :00 stamp (not hourly means).")
    by_ver = summ.groupby("version")["sza_offset_min"].agg(lambda s: sorted(int(v) for v in s.unique()))
    log("offset by version label: " + "; ".join(f"{k or 'blank'}: {v}" for k, v in by_ver.items()))

    # ---------------------------------------------------------------- 3
    section("3. PHYSICAL CHECKS (% of daytime hours)")
    cols = ["pct_ghi_above_cs", "pct_closure_fail", "pct_dhi_above_ghi"]
    log(summ.groupby("site_id")[cols].mean().round(2).to_string())
    log(f"negative GHI values: {summ.n_ghi_negative.sum()},  GHI>5 W/m2 at night: {summ.n_ghi_night.sum()}")

    # ---------------------------------------------------------------- 4
    section("4. NSRDB FLAGS")
    log("fill_flag labels (from file headers): " + ", ".join(f"{k}={v}" for k, v in sorted(ff_all.items())))
    log("cloud_type labels: " + ", ".join(f"{k}={v}" for k, v in sorted(ct_all.items())))
    log("% of daytime hours gap-filled, per site (mean over years):")
    log(summ.groupby("site_id")["pct_filled_day"].mean().round(2).to_string())
    mix = {}
    for fm in summ.fill_mix:
        for kv in fm.split("|"):
            k, v = kv.split(":"); mix.setdefault(int(k), []).append(float(v))
    log("daytime share per fill_flag code (mean over site-years): " +
        ", ".join(f"{k}({ff_all.get(k, '?')})={np.mean(v):.1f}%" for k, v in sorted(mix.items())))
    log("cloud_type codes seen (daytime): " + str(sorted({c for s in summ.cloud_codes for c in s.split("|")},
                                                          key=lambda x: int(x))))

    # ---------------------------------------------------------------- 5
    section("5. VERSION CHECK: is 2020 (v3.1.1, TEST year) consistent with 2016-2019 (unknown)?")
    log("For each metric: z = (2020 - mean 2016-19) / std 2016-19 per site.")
    log("|z| <= 3 is normal year-to-year variation; |z| > 3 at many sites suggests a")
    log("processing change in 2020.")
    flagged_sites = 0
    zrows = []
    for sid, g in summ.groupby("site_id"):
        hist, t = g[g.year < 2020], g[g.year == 2020]
        if t.empty or len(hist) < 3:
            continue
        r = dict(site_id=sid)
        for m in ["mean_cs_day", "mean_ghi_day", "mean_kc_day", "kc_q10", "kc_q50", "kc_q90",
                  "kc_clear_median", "pct_filled_day", "sza_offset_min"]:
            h, v = hist[m].dropna(), t[m].iloc[0]
            sd = h.std()
            if len(h) < 3 or pd.isna(v) or not np.isfinite(sd):
                r[m] = float("nan")                       # not computable
            elif sd < 1e-9:
                r[m] = 0.0 if abs(v - h.mean()) < 1e-9 else float("nan")  # constant metric
            else:
                r[m] = round(float((v - h.mean()) / sd), 1)
        r["new_cloud_codes"] = ",".join(sorted(set(t.cloud_codes.iloc[0].split("|")) -
                                               set("|".join(hist.cloud_codes).split("|"))))
        zrows.append(r)
        core = [r[m] for m in ["mean_cs_day", "mean_ghi_day", "mean_kc_day", "kc_q10", "kc_q50"]]
        if any(np.isfinite(z) and abs(z) > 3 for z in core):
            flagged_sites += 1
    zdf = pd.DataFrame(zrows).set_index("site_id")
    log(zdf.to_string())
    n = len(zdf)
    log("\nNote: z uses only 4 reference years, so it is a screening tool, not proof.")
    log("Header comparison (metadata fields and column count, excluding location fields):")
    for yr_set, g in summ.groupby(summ.year == 2020):
        log(f"  {'2020     ' if yr_set else '2016-2019'}: {g.header_signature.nunique()} distinct "
            f"header(s), columns {sorted(int(c) for c in g.n_columns.unique())}")
    h_old = set("|".join(summ[summ.year < 2020].header_signature).split("|"))
    h_new = set("|".join(summ[summ.year == 2020].header_signature).split("|"))
    log(f"  fields only in 2020: {sorted(h_new - h_old) or 'none'}")
    log(f"  fields only in 2016-2019: {sorted(h_old - h_new) or 'none'}")
    log(f"\nsites with |z|>3 in clear-sky GHI, GHI, mean k_c, k_c q10 or q50: {flagged_sites} / {n}")
    if flagged_sites <= max(1, n // 10):
        log("SCREENING RESULT: no systematic 2020 shift found -> 'unknown' is consistent with "
            "missing metadata. Provisional: confirm with NREL (nsrdb@nlr.gov) before submission.")
    else:
        log("SCREENING RESULT: 2020 differs systematically -> do NOT use 2020 as test year as-is. "
            "Ask nsrdb@nlr.gov about the 2016-2019 version; consider testing on 2019.")

    # ---------------------------------------------------------------- save
    section("6. OUTPUT")
    allc = pd.concat(frames, ignore_index=True)
    keep_first = ["site_id", "time", "year", "month", "day", "hour", "minute"]
    allc = allc[keep_first + [c for c in allc.columns if c not in keep_first]]
    allc.to_parquet(OUT_PARQUET, index=False)
    log(f"combined dataset : {OUT_PARQUET}  ({len(allc):,} rows, {allc.site_id.nunique()} sites)")
    log(f"  qc_any flagged : {100 * allc.loc[allc.solar_zenith_angle < 90, 'qc_any'].mean():.2f}% "
        "of daytime hours (kept, flagged; script 4 decides)")

    m = pd.DataFrame(metas)
    sm = (m.groupby("site_id").agg(ret_lat=("ret_lat", "first"), ret_lon=("ret_lon", "first"),
                                   elevation_m=("elevation_m", "first"), tz=("tz", "first"),
                                   n_pixels=("ret_lat", lambda s: s.round(3).nunique()))
          .reset_index())
    sm = sm.merge(pd.DataFrame(list(sites.values()))[["site_id", "name", "region", "lat", "lon"]]
                  .rename(columns={"lat": "req_lat", "lon": "req_lon"}), on="site_id")
    sm.to_csv(SITE_META_CSV, index=False)
    moved = sm[sm.n_pixels > 1]
    log(f"site metadata    : {SITE_META_CSV}")
    log("same pixel in every year for all sites" if moved.empty else
        f"!! pixel changed between years: {moved.site_id.tolist()}")
    log(f"per site-year summary: {SUMMARY_CSV}")

    with open(REPORT_TXT, "w", encoding="utf-8") as f:
        f.write("\n".join(_lines))
    print(f"\nReport saved: {REPORT_TXT}  -> send this file to Claude")


if __name__ == "__main__":
    main()