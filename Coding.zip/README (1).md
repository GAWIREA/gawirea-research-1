# GenerativeAURORA v2

Probabilistic day-ahead solar irradiance forecasting for Indonesia with a conditional
diffusion model. 27 sites in 7 regions, NSRDB Himawari PSM v3 data 2016–2020.

The scripts are numbered in the order they run. Each step reads the output of the
steps before it. The paper's results come from running steps 1 → 11 once, in this order.

## Main pipeline

| Step | Script | What it does | Main output |
|---|---|---|---|
| 1 | `1_config.py` | Settings used by every script: 27-site registry, data product, years, data splits, seeds, folders. Run it alone to check the site list. | (imported by all) |
| 2 | `2_download_himawari.py` | Downloads raw NSRDB Himawari data (27 sites × 5 years) and logs product version, satellite pixel and checksum of every file. | `Dataset/raw/`, `download_log.csv` |
| 3 | `3_quality_control.py` | Checks completeness, time convention, physical consistency, NSRDB flags, and whether 2020 differs from 2016–2019. | `himawari_qc.parquet`, `qc_report.txt` |
| 4 | `4_build_dataset.py` | Builds forecast samples: inputs from day D−1 and earlier, target = clear-sky index of day D, masks, splits, leakage checks. | `aurora_dataset.npz`, `dataset_report.txt` |
| 5 | `5_model.py` | Defines GenerativeAURORA (encoders, 1-D U-Net, diffusion, sampling). Run it alone for a self-test. | (imported) |
| 6 | `6_train.py` | Trains models (5 seeds); hyperparameter search with Optuna on validation data. | `Checkpoints/`, training summaries |
| 7 | `7_calibrate.py` | Generates 100 scenarios per day; fits calibration (point-mass snap + conformal intervals) on the calibration weeks. | `Results/scenarios/`, `Results/calibration/` |
| 8 | `8_evaluate.py` | Scores forecasts (CRPS, energy, variogram, PIT) and compares with climatology and persistence. | `Results/evaluation/` |
| 9 | `9_baselines.py` | Trains and evaluates 4 baselines (LSTM-QR, Transformer-QR, CVAE, MC-Dropout) with the same inputs and procedure; prints the comparison table. | `Results/baselines/` |
| 10 | `10_spatial_holdout.py` | Leave-one-region-out test: retrain without a region, then forecast that region. | `Results/spatial/` |
| 11 | `11_final_test.py` | Freezes the protocol; one-time 2020 test of all models; significance tests; 2019 sensitivity run. | `Results/final/final_test_report.txt` |

## Checking tools (read-only, change no result)

| Script | What it does |
|---|---|
| `12_compare_configs.py` | Confirms two trained models differ only in the setting under study (used for the cosine vs linear comparison). |
| `13_fix_dataset_metadata.py` | One-off fix of a text label in `aurora_dataset.json`; proves the training data file is unchanged (MD5). Already applied. |

`0_diagnose_aurora.py` (in the old v1 folder) is the audit of the original v1 code.

## Important rules

- **Do not run `4_build_dataset.py` again.** It would rebuild the dataset the models were trained on.
- **The 2020 test year has been opened once** (`11_final_test.py`). Do not retrain or re-tune using it.
- Statistics only (no models, no new forecasts): `python 11_final_test.py --stats-only`
- The scripts import each other by file name, so **do not rename them**.
- On GitHub, files are listed alphabetically (`10_`–`13_` appear before `1_`); follow the step numbers in this table.

## Reproducing from scratch (Windows PowerShell)

```powershell
setx NREL_API_KEY "YOUR_OWN_KEY"     # never written into the code
setx NREL_EMAIL  "you@example.com"
python 2_download_himawari.py
python 3_quality_control.py
python 4_build_dataset.py
python 6_train.py --tune 30 --tune-epochs 120
python 6_train.py --params Results/tuning/main_best_params.json --seeds 0,1,2,3,4 --name small --base-ch 24
python 7_calibrate.py --run main_small
python 8_evaluate.py --run main_small
python 9_baselines.py
python 10_spatial_holdout.py --ga-base-ch 24
python 11_final_test.py --alt
```

Environment: Python 3.12, PyTorch 2.5.1 (CUDA 12.1), NVIDIA RTX 4080 SUPER.

## Folder layout

```
GenerativeAURORA_v2/
├── 1_config.py ... 13_fix_dataset_metadata.py, README.md
├── Dataset/
│   ├── raw/himawari/<site>/<year>.csv   raw NSRDB files (not shared; download with step 2)
│   ├── processed/                       QC parquet, aurora_dataset.npz / .json
│   └── metadata/                        site_meta.csv, download_log.csv
├── Checkpoints/                         trained models
└── Results/
    ├── qc/  dataset/  tuning/  training/
    ├── scenarios/  calibration/  evaluation/
    ├── baselines/  spatial/
    └── final/                           frozen_protocol.json, final_test_report.txt
```

Note: `dataset_report.txt` was written before a label fix; its heading
"SKY REGIMES (satellite cloud classes)" is outdated. Regimes are based on the daily
mean clear-sky index (Clear ≥ 0.85, Overcast ≤ 0.40), as in the code and in
`aurora_dataset.json`.
