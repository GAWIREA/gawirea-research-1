"""
GenerativeAURORA v2 - 7_calibrate.py
====================================
1. Generates K scenarios per day with a trained model for the 'cal' and
   'test' splits (cached in Results/scenarios/, reused by 8_evaluate.py).
2. Calibrates prediction intervals with split conformal prediction on the
   'cal' split ONLY, then applies the frozen corrections to 'test'.

Calibration methods (all use only information available at issue time)
  raw         ensemble quantiles, no correction
  marginal    one correction q for all hours (target: hourly coverage)
  mondrian    one q per PREVIOUS-DAY regime (regime_proxy, known at issue).
              This is the corrected RCCC: Paper 1 chose q with the realised
              regime of the forecast day, which is not available in practice.
  normalized  q scales with the ensemble's own spread (width of the raw
              interval, floor W_MIN): hours/days where the model is unsure get
              proportionally wider bands (normalised conformal, Lei et al. 2018)
  trajectory  q from the worst hour of each day (target: whole-day coverage,
              i.e. all valid hours of a day inside the band simultaneously)

The realised regime (regime_true) and region are used ONLY afterwards, to
REPORT coverage per group. They never influence an interval.

Honest caveat (for the paper): conformal guarantees assume exchangeable
calibration and test days. Confidence intervals use a cluster bootstrap over
calendar dates (sites on the same date share weather). Our cal days are 2019 (even ISO weeks) and test
days are 2020, so coverage is an empirical result, not a guarantee; hours
within a day are also dependent. We therefore report achieved coverage with
bootstrap confidence intervals instead of claiming a theorem.

Usage
    python 7_calibrate.py                       # default: evaluates on 'val' (test untouched)
    python 7_calibrate.py --target test         # FINAL only: tuned 5-seed models, test set
    python 7_calibrate.py --run main --seeds 0
    python 7_calibrate.py --run alt             # experiment with test year 2019
    python 7_calibrate.py --K 100 --steps 50    # scenarios / DDIM steps
"""

import os
import sys
import glob
import json
import argparse
import importlib
from datetime import datetime

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
cfg = importlib.import_module("1_config")

LEVELS = [0.80, 0.90, 0.95]
REGIMES = ["Clear", "Cloudy", "Overcast"]
MIN_GROUP = 30
W_MIN = 0.02            # floor on raw width (k_c) for the normalized method          # Mondrian group smaller than this -> use the marginal q
N_BOOT = 500

SCEN_DIR = os.path.join(cfg.RESULT_DIR, "scenarios")
OUT_DIR = os.path.join(cfg.RESULT_DIR, "calibration")


# ----------------------------------------------------------------------------
# 1. Scenario generation (needs torch + the trained checkpoint)
# ----------------------------------------------------------------------------
def generate(run, seed, split, K, steps, regen=False):
    path = os.path.join(SCEN_DIR, run, f"seed{seed}_{split}.npz")
    if os.path.exists(path) and not regen:
        return path
    import torch
    M = importlib.import_module("5_model")
    ck_path = os.path.join(cfg.CKPT_DIR, run, f"seed{seed}", "best.pt")
    ck = torch.load(ck_path, map_location="cpu", weights_only=False)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = M.GenerativeAURORA(ck["dims"], ck["mc"]).to(dev)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    data = dict(np.load(M.DATA_NPZ, allow_pickle=True))
    d = M.load_split(data, split, ck["experiment"])
    g = torch.Generator(device=dev).manual_seed(10_000 + seed)
    out = []
    bs = max(1, 12_800 // K)
    for s in range(0, len(d["y"]), bs):
        b = M.to_batch(d, np.arange(s, min(s + bs, len(d["y"]))), dev)
        out.append(model.sample(b, K=K, steps=steps, generator=g).cpu().numpy().astype(np.float16))
        print(f"  {split}: {min(s + bs, len(d['y']))}/{len(d['y'])} days", end="\r")
    print()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path, S=np.concatenate(out), y=d["y"], m_y=d["m_y"],
                        clearsky=d["clearsky"], ghi=d["ghi"], date=d["date"],
                        site_id=d["site_id"], region=d["region"],
                        regime_true=d["regime_true"], regime_proxy=d["regime_proxy"],
                        experiment=ck["experiment"], epoch=ck["epoch"], K=K, steps=steps)
    return path


# ----------------------------------------------------------------------------
# 2. Conformal calibration (numpy only)
# ----------------------------------------------------------------------------
def bounds(S, level):
    a = 1 - level
    return np.quantile(S, a / 2, axis=1), np.quantile(S, 1 - a / 2, axis=1)


def conformal_q(scores, level):
    scores = np.sort(np.asarray(scores, dtype=float))
    n = len(scores)
    if n == 0:
        return np.nan
    k = int(np.ceil((n + 1) * level))
    return float(scores[min(k, n) - 1])


def hour_scores(lo, hi, y, m):
    s = np.maximum(lo - y, y - hi)
    return s[m > 0]


def day_scores(lo, hi, y, m):
    s = np.where(m > 0, np.maximum(lo - y, y - hi), -np.inf)
    return s.max(axis=1)


def fit(cal, level, w_min=None):
    w_min = W_MIN if w_min is None else w_min
    S = cal["S"].astype(np.float32)
    lo, hi = bounds(S, level)
    y, m = cal["y"], cal["m_y"]
    q = dict(raw=0.0, marginal=conformal_q(hour_scores(lo, hi, y, m), level))
    q["trajectory"] = conformal_q(day_scores(lo, hi, y, m), level)
    w = np.maximum(hi - lo, w_min)
    q["normalized"] = conformal_q((np.maximum(lo - y, y - hi) / w)[m > 0], level)
    q["w_min"] = w_min
    qm = {}
    for r in range(3):
        sel = cal["regime_proxy"] == r
        if sel.sum() >= MIN_GROUP:
            qm[r] = conformal_q(hour_scores(lo[sel], hi[sel], y[sel], m[sel]), level)
        else:
            qm[r] = q["marginal"]
    q["mondrian"] = qm
    return q


def apply(test, level, q, method):
    S = test["S"].astype(np.float32)
    lo, hi = bounds(S, level)
    if method == "mondrian":
        qq = np.array([q["mondrian"][int(r)] for r in test["regime_proxy"]])[:, None]
    elif method == "normalized":
        qq = q["normalized"] * np.maximum(hi - lo, q["w_min"])
    else:
        qq = q[method]
    sun = (S.max(axis=1) > 0) | (test["m_y"] > 0)
    L = np.clip(lo - qq, 0, 1) * sun
    U = np.clip(hi + qq, 0, 1) * sun
    return L, U


def boot_ci(num, den, dates, n_boot=N_BOOT, seed=0):
    """Cluster bootstrap over CALENDAR DATES: all hours of all sites on the same
    date are resampled together, because sites share weather on the same day."""
    if len(num) == 0:
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    _, inv = np.unique(dates, return_inverse=True)
    n_d = inv.max() + 1
    num_d = np.bincount(inv, weights=num, minlength=n_d)
    den_d = np.bincount(inv, weights=den, minlength=n_d)
    stats = []
    for _ in range(n_boot):
        i = rng.integers(0, n_d, n_d)
        stats.append(num_d[i].sum() / max(den_d[i].sum(), 1))
    return np.percentile(stats, 2.5) * 100, np.percentile(stats, 97.5) * 100


def score(test, L, U, sel=None, level=0.9):
    y, m, cs, dates = test["y"], test["m_y"], test["clearsky"], test["date"]
    if sel is not None:
        y, m, cs, L, U, dates = y[sel], m[sel], cs[sel], L[sel], U[sel], dates[sel]
    inside = ((y >= L) & (y <= U)) * m
    num, den = inside.sum(1), m.sum(1)
    cov = num.sum() / max(den.sum(), 1) * 100
    lo_ci, hi_ci = boot_ci(num, den, dates)
    day_cov = np.mean(num[den > 0] == den[den > 0]) * 100
    w = ((U - L) * m).sum() / max(m.sum(), 1)
    w_wm2 = ((U - L) * cs * m).sum() / max(m.sum(), 1)
    a = 1 - level
    # Winkler interval score (Gneiting & Raftery 2007): proper score that
    # rewards narrow bands and penalises misses; lower is better
    isc = (U - L) + (2 / a) * np.maximum(L - y, 0) + (2 / a) * np.maximum(y - U, 0)
    iscore = (isc * m).sum() / max(m.sum(), 1)
    return dict(n_days=int(len(y)), coverage=cov, cov_ci_lo=lo_ci, cov_ci_hi=hi_ci,
                day_coverage=day_cov, width_kc=w, width_wm2=w_wm2, interval_score=iscore)


def is_capped(y, m):
    return np.isclose(y, 1.0, atol=1e-6) & (m > 0)


def fit_snap(cal):
    """The data has a point mass at k_c = 1 (NSRDB caps clear-sky hours). The
    diffusion samples are continuous and stop just below 1. Choose delta on the
    CAL split so that the share of samples >= 1-delta equals the share of
    observed k_c == 1, then set those samples to exactly 1 (quantile matching
    of the point mass)."""
    m = cal["m_y"] > 0
    p1 = is_capped(cal["y"], cal["m_y"]).sum() / max(m.sum(), 1)
    Sv = cal["S"].astype(np.float32).transpose(0, 2, 1)[m].ravel()
    if p1 <= 0:
        return 0.0, p1
    return float(1.0 - np.quantile(Sv, 1.0 - p1)), float(p1)


def snap(S, delta):
    S = S.astype(np.float32)
    if delta > 0:
        S = np.where(S >= 1.0 - delta, 1.0, S)
    return S


def calibrate(run, seed, log, target="test"):
    cal = dict(np.load(os.path.join(SCEN_DIR, run, f"seed{seed}_cal.npz"), allow_pickle=True))
    test = dict(np.load(os.path.join(SCEN_DIR, run, f"seed{seed}_{target}.npz"), allow_pickle=True))
    rows, qs = [], {}
    # raw intervals BEFORE the point-mass correction, for transparency
    for level in LEVELS:
        lo, hi = bounds(test["S"].astype(np.float32), level)
        rows.append(dict(seed=seed, level=level, method="raw_unsnapped", group="all",
                         **score(test, np.clip(lo, 0, 1), np.clip(hi, 0, 1), level=level)))
    delta, p1 = fit_snap(cal)
    cal["S"], test["S"] = snap(cal["S"], delta), snap(test["S"], delta)
    for level in LEVELS:
        q = fit(cal, level)
        qs[str(level)] = {k: (v if not isinstance(v, dict) else {REGIMES[r]: x for r, x in v.items()})
                          for k, v in q.items()}
        for method in ["raw", "marginal", "mondrian", "normalized", "trajectory"]:
            L, U = apply(test, level, q, method)
            groups = [("all", None)]
            groups += [(f"regime={REGIMES[r]}", test["regime_true"] == r) for r in range(3)]
            groups += [(f"region={g}", test["region"] == g) for g in sorted(set(test["region"]))]
            for gname, sel in groups:
                if sel is not None and sel.sum() == 0:
                    continue
                rows.append(dict(seed=seed, level=level, method=method, group=gname,
                                 **score(test, L, U, sel, level)))
    df = pd.DataFrame(rows)
    os.makedirs(OUT_DIR, exist_ok=True)
    df.to_csv(os.path.join(OUT_DIR, f"{run}_seed{seed}_{target}_calibration.csv"), index=False)
    with open(os.path.join(OUT_DIR, f"{run}_seed{seed}_q.json"), "w") as f:
        json.dump(dict(run=run, seed=seed, snap_delta=delta, p_capped_cal=p1,
                       n_cal_days=int(len(cal["y"])),
                       n_cal_hours=int(cal["m_y"].sum()), q=qs,
                       note="q in k_c units; fitted on split 'cal' only"), f, indent=2)

    log(f"\n--- {run} seed {seed}: evaluated on '{target}' {len(test['y'])} days, cal {len(cal['y'])} days, "
        f"K={int(test['K'])} scenarios, checkpoint epoch {int(test['epoch'])}")
    log(f"point mass at k_c = 1: {100 * p1:.1f}% of cal hours; samples >= {1 - delta:.4f} set to 1.000 "
        f"(delta {delta:.4f}, fitted on cal)")
    for level in LEVELS:
        log(f"\nnominal {int(level * 100)}% interval     coverage [95% CI]        "
            f"whole-day   width k_c   width W/m2   interval score")
        a = df[(df.level == level) & (df.group == "all")]
        a = pd.concat([a[a.method == "raw_unsnapped"], a[a.method != "raw_unsnapped"]])
        for _, r in a.iterrows():
            log(f"  {r.method:13s}   {r.coverage:6.2f}% [{r.cov_ci_lo:5.1f}-{r.cov_ci_hi:5.1f}]   "
                f"{r.day_coverage:8.1f}%   {r.width_kc:8.3f}   {r.width_wm2:8.1f}   {r.interval_score:10.4f}")
    y_, m_ = test["y"], test["m_y"]
    capped = is_capped(y_, m_)
    at1 = capped.sum() / max(m_.sum(), 1) * 100
    raw_S = np.load(os.path.join(SCEN_DIR, run, f"seed{seed}_{target}.npz"))["S"].astype(np.float32)
    hi90 = np.quantile(raw_S, 0.95, axis=1)
    miss1 = (capped & (hi90 < y_)).sum() / max(m_.sum(), 1) * 100
    log(f"\nvalid hours with k_c == 1.000 exactly (capped clear sky): {at1:.1f}%; before snapping, "
        f"{miss1:.1f}% of all valid hours were raw-90% misses only because the ensemble top "
        "stayed just below 1.000")
    t = df[(df.level == 0.90) & df.group.str.startswith("regime=")]
    log("\n90% coverage by REALISED regime (reporting only):")
    log(t.pivot_table(index="group", columns="method", values="coverage").round(2).to_string())
    log("90% interval score by realised regime (lower = better):")
    log(t.pivot_table(index="group", columns="method", values="interval_score").round(4).to_string())
    n_by = t[t.method == "raw"].set_index("group")["n_days"]
    log("days: " + ", ".join(f"{k.split('=')[1]}={v}" for k, v in n_by.items()))
    log("\nSensitivity of 'normalized' to the width floor W_MIN (90% level):")
    log(f"  {'W_MIN':>6s} {'all':>7s} {'Clear':>7s} {'Cloudy':>7s} {'Overcast':>9s} {'W/m2':>7s}")
    for wm in [0.01, 0.02, 0.05, 0.10]:
        qn = fit(cal, 0.90, wm)
        L, U = apply(test, 0.90, qn, "normalized")
        r_all = score(test, L, U)
        rc = [score(test, L, U, test["regime_true"] == r)["coverage"] for r in range(3)]
        log(f"  {wm:6.2f} {r_all['coverage']:6.2f}% {rc[0]:6.2f}% {rc[1]:6.2f}% {rc[2]:8.2f}% "
            f"{r_all['width_wm2']:7.1f}")
    log("\n90% coverage by REGION, mondrian method (reporting only):")
    t = df[(df.level == 0.90) & df.group.str.startswith("region=") & (df.method == "mondrian")]
    log(t.set_index("group")[["coverage", "cov_ci_lo", "cov_ci_hi", "width_wm2"]].round(2).to_string())
    log("q (k_c) per level/method: " + json.dumps(
        {lv: {k: (round(v, 4) if isinstance(v, float) else {kk: round(vv, 4) for kk, vv in v.items()})
              for k, v in qq.items()} for lv, qq in qs.items()}))
    return df


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="main", help="run folder in Checkpoints/ (e.g. main, alt, main_lin)")
    ap.add_argument("--seeds", default="", help="default: every seed folder found")
    ap.add_argument("--K", type=int, default=100)
    ap.add_argument("--steps", type=int, default=50)
    ap.add_argument("--regen", action="store_true", help="regenerate cached scenarios")
    ap.add_argument("--target", default="val", choices=["test", "val"],
                    help="default 'val' (safe while developing); 'test' ONCE for the final models")
    args = ap.parse_args()

    if args.seeds:
        seeds = [int(s) for s in args.seeds.split(",")]
    else:
        seeds = sorted(int(os.path.basename(p)[4:]) for p in
                       glob.glob(os.path.join(cfg.CKPT_DIR, args.run, "seed*"))
                       if os.path.exists(os.path.join(p, "best.pt")))
    if not seeds:
        sys.exit(f"no trained checkpoints in {os.path.join(cfg.CKPT_DIR, args.run)}")

    lines = []

    def log(*a):
        s = " ".join(str(x) for x in a)
        print(s)
        lines.append(s)

    log(f"GenerativeAURORA v2 - calibration  {datetime.now().isoformat(timespec='seconds')}")
    log(f"run '{args.run}', seeds {seeds}, K={args.K}, DDIM steps={args.steps}, "
        f"evaluated on '{args.target}'")
    if args.target == "test":
        log("!! TEST SET: use this only once, for the final tuned models")
    all_df = []
    for seed in seeds:
        for split in ["cal", args.target]:
            print(f"scenarios seed {seed} {split} ...")
            generate(args.run, seed, split, args.K, args.steps, args.regen)
        all_df.append(calibrate(args.run, seed, log, args.target))

    if len(seeds) > 1:
        df = pd.concat(all_df)
        a = df[(df.group == "all")].groupby(["level", "method"])[["coverage", "width_wm2"]] \
            .agg(["mean", "std"]).round(2)
        log("\n=== across seeds (mean, std) ===")
        log(a.to_string())
    os.makedirs(OUT_DIR, exist_ok=True)
    rep = os.path.join(OUT_DIR, f"{args.run}_{args.target}_calibration_report.txt")
    with open(rep, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"\nReport saved: {rep}  -> send this file to Claude")


if __name__ == "__main__":
    main()