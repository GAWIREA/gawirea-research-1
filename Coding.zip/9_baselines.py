"""
GenerativeAURORA v2 - 9_baselines.py
====================================
Friend's comment 8: compare against architectures that are equally complex.

Four probabilistic baselines. All share the SAME condition encoder as
GenerativeAURORA (PastEncoder on day D-1, history MLP, geographic MLP, and the
day-D sun geometry per hour), so they see exactly the same information. Only
the way the probabilistic output is produced differs:

  lstmqr    LSTM-QR          2-layer BiLSTM -> 49 quantiles per hour (pinball loss)
  transqr   Transformer-QR   3-layer Transformer encoder over the 16 hours -> 49 quantiles
  cvae      CVAE             latent-variable generative model (Kingma & Welling 2014;
                             Sohn et al. 2015), Gaussian likelihood with learned noise
  mcdrop    MC-Dropout LSTM  Gal & Ghahramani (2016) with a Gaussian likelihood:
                             dropout kept on at sampling time

Quantile models produce trajectories by drawing ONE uniform rank per scenario
and reading every hour at that rank (rank-coherent sampling), so their
scenarios are smooth whole-day curves rather than independent hourly noise.

Fairness protocol (identical to GenerativeAURORA)
  - same train / val / cal splits, same masks, same EMA, same early stopping
    on validation CRPS of 20 sampled scenarios, same 5 seeds
  - equal tuning budget: learning rate chosen from {1e-4, 3e-4, 1e-3} on the
    validation split (seed 0), documented in Results/baselines/
  - scenarios (K = 100) are written in the same format, then calibrated with
    7_calibrate.py (point-mass snap + conformal) and scored with 8_evaluate.py

Usage
    python 9_baselines.py                          # all 4 baselines, lr search, 5 seeds,
                                                   # then calibration + evaluation on 'val'
    python 9_baselines.py --models cvae,mcdrop --seeds 0
    python 9_baselines.py --compare                # only print the comparison table
"""

import os
import sys
import glob
import json
import argparse
import subprocess
import importlib

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
cfg = importlib.import_module("1_config")
M = importlib.import_module("5_model")
TR = importlib.import_module("6_train")

LR_GRID = [1e-4, 3e-4, 1e-3]
OUT_DIR = os.path.join(cfg.RESULT_DIR, "baselines")
SCEN_DIR = os.path.join(cfg.RESULT_DIR, "scenarios")
TAUS = torch.linspace(0.01, 0.99, 49)


def _tuned_dropout():
    p = os.path.join(cfg.RESULT_DIR, "tuning", "main_best_params.json")
    try:
        return float(json.load(open(p))["best_params"].get("dropout", 0.0))
    except (OSError, ValueError, KeyError):
        return float(M.MODEL_CFG["dropout"])


ENC_DROPOUT = _tuned_dropout()   # condition-MLP dropout identical to the tuned GenerativeAURORA


# ----------------------------------------------------------------------------
# Shared condition encoder (identical information to GenerativeAURORA)
# ----------------------------------------------------------------------------
class CondEncoder(nn.Module):
    def __init__(self, dims, H=128, C=128, dropout=0.0):
        super().__init__()
        self.past = M.PastEncoder(dims["past"], H)
        self.hist = M.mlp(2 * dims["hist"], C, C)
        self.geo = M.mlp(dims["static"], C, C)
        self.vec = M.mlp(H + 2 * C, C, C, dropout)   # same dropout as GenerativeAURORA's cond MLP
        self.tok_dim = H + dims["future"] + C

    def forward(self, b):
        seq, glob = self.past(b["x_past"])                       # [B,H,L], [B,H]
        vec = self.vec(torch.cat([glob, self.hist(torch.cat([b["x_hist"], b["m_hist"]], -1)),
                                  self.geo(b["x_static"])], -1))
        L = seq.shape[-1]
        tok = torch.cat([seq.transpose(1, 2), b["x_future"], vec[:, None, :].expand(-1, L, -1)], -1)
        return tok, vec                                          # [B,L,H+F+C]


class Base(nn.Module):
    """Common interface used by 6_train.train_one: loss(b, t, noise), sample(b, K, steps, ...)."""
    def __init__(self, dims, mc):
        super().__init__()
        self.dims, self.mc = dims, dict(mc, T=1)
        self.enc = CondEncoder(dims, dropout=mc.get("dropout", ENC_DROPOUT))
        self.sun_idx = dims["sun_idx"]

    def finish(self, S, b):
        sun = b["x_future"][:, :, self.sun_idx][:, None, :]
        return S.clamp(0, 1) * sun


# ----------------------------------------------------------------------------
# Quantile-regression baselines
# ----------------------------------------------------------------------------
class QuantileBase(Base):
    def quantiles(self, b):
        raise NotImplementedError

    def head_out(self, h):                      # monotone quantiles
        raw = self.out(h)                       # [B,L,Q]
        q0 = raw[..., :1]
        inc = F.softplus(raw[..., 1:])
        return torch.cat([q0, q0 + torch.cumsum(inc, -1)], -1)

    def loss(self, b, t=None, noise=None):
        q = self.quantiles(b)
        taus = TAUS.to(q.device)
        e = b["y"][..., None] - q
        pin = torch.maximum(taus * e, (taus - 1) * e).mean(-1)
        m = b["m_y"]
        return (pin * m).sum() / m.sum().clamp(min=1)

    @torch.no_grad()
    def sample(self, b, K=50, steps=None, eta=None, generator=None):
        q = self.quantiles(b)                                    # [B,L,Q]
        B, L, Q = q.shape
        u = torch.rand(B, K, device=q.device, generator=generator) * (Q - 1)  # one rank per scenario
        lo = u.floor().long().clamp(max=Q - 2)
        w = (u - lo.float())[..., None]                          # [B,K,1]
        qe = q[:, None, :, :].expand(B, K, L, Q)
        a = torch.gather(qe, 3, lo[:, :, None, None].expand(B, K, L, 1)).squeeze(-1)
        c = torch.gather(qe, 3, (lo + 1)[:, :, None, None].expand(B, K, L, 1)).squeeze(-1)
        return self.finish(a + w * (c - a), b)


class LSTMQR(QuantileBase):
    def __init__(self, dims, mc):
        super().__init__(dims, mc)
        self.rnn = nn.LSTM(self.enc.tok_dim, 128, num_layers=2, batch_first=True,
                           bidirectional=True, dropout=0.1)
        self.out = nn.Linear(256, len(TAUS))

    def quantiles(self, b):
        tok, _ = self.enc(b)
        self.rnn.flatten_parameters()
        h, _ = self.rnn(tok)
        return self.head_out(h)


class TransQR(QuantileBase):
    def __init__(self, dims, mc):
        super().__init__(dims, mc)
        d = 128
        self.proj = nn.Linear(self.enc.tok_dim, d)
        self.pos = nn.Parameter(torch.zeros(1, dims["L"], d))
        layer = nn.TransformerEncoderLayer(d, 4, 256, dropout=0.1, batch_first=True)
        self.tf = nn.TransformerEncoder(layer, 3)
        self.out = nn.Linear(d, len(TAUS))

    def quantiles(self, b):
        tok, _ = self.enc(b)
        return self.head_out(self.tf(self.proj(tok) + self.pos))


# ----------------------------------------------------------------------------
# CVAE
# ----------------------------------------------------------------------------
class CVAE(Base):
    def __init__(self, dims, mc, z=16):
        super().__init__(dims, mc)
        self.z = z
        self.q_rnn = nn.GRU(self.enc.tok_dim + 1, 128, batch_first=True, bidirectional=True)
        self.q_out = nn.Linear(256, 2 * z)
        self.d_rnn = nn.GRU(self.enc.tok_dim + z, 128, num_layers=2, batch_first=True,
                            bidirectional=True, dropout=0.1)
        self.d_out = nn.Linear(256, 1)
        self.log_sigma = nn.Parameter(torch.tensor(-2.0))       # learned observation noise

    def decode(self, tok, z):
        L = tok.shape[1]
        self.d_rnn.flatten_parameters()
        h, _ = self.d_rnn(torch.cat([tok, z[:, None, :].expand(-1, L, -1)], -1))
        return torch.sigmoid(self.d_out(h).squeeze(-1))

    def loss(self, b, t=None, noise=None):
        tok, _ = self.enc(b)
        m = b["m_y"]
        y = b["y"] * m
        self.q_rnn.flatten_parameters()
        h, _ = self.q_rnn(torch.cat([tok, y[..., None]], -1))
        mu, logvar = self.q_out(h.mean(1)).chunk(2, -1)
        zz = mu + torch.randn_like(mu) * (0.5 * logvar).exp()
        mean = self.decode(tok, zz)
        ls = self.log_sigma.clamp(-5, 1)
        nll = 0.5 * ((y - mean) ** 2 / (2 * ls).exp() + 2 * ls)
        kl = -0.5 * (1 + logvar - mu ** 2 - logvar.exp()).sum(-1)
        return ((nll * m).sum() + kl.sum()) / m.sum().clamp(min=1)

    @torch.no_grad()
    def sample(self, b, K=50, steps=None, eta=None, generator=None):
        tok, _ = self.enc(b)
        B, L, D = tok.shape
        tok = tok.repeat_interleave(K, 0)
        z = torch.randn(B * K, self.z, device=tok.device, generator=generator)
        mean = self.decode(tok, z)
        eps = torch.randn(mean.shape, device=tok.device, generator=generator)
        y = mean + self.log_sigma.clamp(-5, 1).exp() * eps
        return self.finish(y.view(B, K, L), b)


# ----------------------------------------------------------------------------
# MC-Dropout LSTM with Gaussian likelihood
# ----------------------------------------------------------------------------
class MCDrop(Base):
    def __init__(self, dims, mc, p=0.2):
        super().__init__(dims, mc)
        self.p = p
        self.rnn = nn.LSTM(self.enc.tok_dim, 128, num_layers=2, batch_first=True,
                           bidirectional=True, dropout=p)
        self.out = nn.Linear(256, 2)

    def forward_once(self, b):
        tok, _ = self.enc(b)
        tok = F.dropout(tok, self.p, training=True)
        self.rnn.flatten_parameters()
        h, _ = self.rnn(tok)
        h = F.dropout(h, self.p, training=True)
        mu, ls = self.out(h).unbind(-1)
        return torch.sigmoid(mu), ls.clamp(-6, 1)

    def loss(self, b, t=None, noise=None):
        mu, ls = self.forward_once(b)
        m = b["m_y"]
        nll = 0.5 * ((b["y"] - mu) ** 2 / (2 * ls).exp() + 2 * ls)
        return (nll * m).sum() / m.sum().clamp(min=1)

    @torch.no_grad()
    def sample(self, b, K=50, steps=None, eta=None, generator=None):
        was = self.training
        self.train()                                   # dropout ON (MC dropout)
        bb = {k: v.repeat_interleave(K, 0) for k, v in b.items()}
        mu, ls = self.forward_once(bb)
        eps = torch.randn(mu.shape, device=mu.device, generator=generator)
        y = mu + ls.exp() * eps
        self.train(was)
        B, L = b["y"].shape if "y" in b else (b["x_future"].shape[0], self.dims["L"])
        return self.finish(y.view(B, K, L), b)


MODELS = {"lstmqr": LSTMQR, "transqr": TransQR, "cvae": CVAE, "mcdrop": MCDrop}


# ----------------------------------------------------------------------------
def generate(model_cls, run, seed, split, data, K=100):
    path = os.path.join(SCEN_DIR, run, f"seed{seed}_{split}.npz")
    ck = torch.load(os.path.join(cfg.CKPT_DIR, run, f"seed{seed}", "best.pt"),
                    map_location="cpu", weights_only=False)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model_cls(ck["dims"], ck["mc"]).to(dev)
    model.load_state_dict(ck["state_dict"])
    model.eval()
    d = M.load_split(data, split, ck["experiment"])
    g = torch.Generator(device=dev).manual_seed(10_000 + seed)
    out = []
    for s in range(0, len(d["y"]), 128):
        b = M.to_batch(d, np.arange(s, min(s + 128, len(d["y"]))), dev)
        out.append(model.sample(b, K=K, generator=g).cpu().numpy().astype(np.float16))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path, S=np.concatenate(out), y=d["y"], m_y=d["m_y"],
                        clearsky=d["clearsky"], ghi=d["ghi"], date=d["date"],
                        site_id=d["site_id"], region=d["region"],
                        regime_true=d["regime_true"], regime_proxy=d["regime_proxy"],
                        experiment=ck["experiment"], epoch=ck["epoch"], K=K, steps=0)
    print(f"  scenarios {run} seed {seed} {split}: {len(d['y'])} days")


def compare(target="val"):
    runs = ["main_tuned", "main_tuned_linear", "main_small"] + [f"base_{k}" for k in MODELS]
    rows = []
    for run in runs:
        p = os.path.join(cfg.RESULT_DIR, "evaluation", f"{run}_{target}_metrics.csv")
        if not os.path.exists(p):
            continue
        df = pd.read_csv(p)
        a = df[(df.group == "all") & (df.model == "GenerativeAURORA")]
        cal = []
        for f in glob.glob(os.path.join(cfg.RESULT_DIR, "calibration", f"{run}_seed*_{target}_calibration.csv")):
            c = pd.read_csv(f)
            r = c[(c.level == 0.9) & (c.method == "mondrian") & (c.group == "all")]
            o = c[(c.level == 0.9) & (c.method == "mondrian") & (c.group == "regime=Overcast")]
            raw = c[(c.level == 0.9) & (c.method == "raw") & (c.group == "all")]
            cal.append((r.coverage.iloc[0], r.width_wm2.iloc[0], r.interval_score.iloc[0],
                        o.coverage.iloc[0] if len(o) else np.nan, raw.coverage.iloc[0]))
        cal = np.array(cal) if cal else np.full((1, 5), np.nan)

        def ms(x):
            return f"{np.mean(x):.4f}+/-{np.std(x, ddof=1) if len(x) > 1 else 0:.4f}"
        sj = glob.glob(os.path.join(cfg.CKPT_DIR, run, "seed*", "summary.json"))
        n_par = json.load(open(sj[0])).get("params", "") if sj else ""
        rows.append({"model": run, "params": f"{n_par / 1e6:.2f}M" if n_par else "", "seeds": len(a),
                     "CRPS k_c": ms(a.crps_kc),
                     "CRPS W/m2": f"{a.crps_wm2.mean():.2f}", "MAE W/m2": f"{a.mae_wm2.mean():.2f}",
                     "energy": f"{a.energy.mean():.4f}", "variogram": f"{a.variogram.mean():.5f}",
                     "CRPSS/CLIM": ms(a.crpss_vs_CLIM),
                     "raw cov90": f"{np.nanmean(cal[:, 4]):.1f}%",
                     "cal cov90": f"{np.nanmean(cal[:, 0]):.1f}%",
                     "width W/m2": f"{np.nanmean(cal[:, 1]):.1f}",
                     "int.score": f"{np.nanmean(cal[:, 2]):.4f}",
                     "Overcast cov": f"{np.nanmean(cal[:, 3]):.1f}%"})
    if not rows:
        print("no evaluation results found yet")
        return
    t = pd.DataFrame(rows)
    os.makedirs(OUT_DIR, exist_ok=True)
    t.to_csv(os.path.join(OUT_DIR, f"comparison_{target}.csv"), index=False)
    txt = t.to_string(index=False)
    print("\n=== MODEL COMPARISON on '%s' (mean over seeds; calibration = mondrian 90%%) ===" % target)
    print(txt)
    with open(os.path.join(OUT_DIR, f"comparison_{target}.txt"), "w", encoding="utf-8") as f:
        f.write(txt + "\n\nraw cov90 = before conformal (after point-mass snap); "
                "cal cov90 / width / int.score = mondrian 90%; Overcast cov = realised overcast days.\n")
    print(f"\nsaved: {os.path.join(OUT_DIR, f'comparison_{target}.txt')}  -> send this file to Claude")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", default=",".join(MODELS))
    ap.add_argument("--seeds", default="0,1,2,3,4")
    ap.add_argument("--no-lr-search", action="store_true")
    ap.add_argument("--compare", action="store_true", help="only print the comparison table")
    args = ap.parse_args()
    if args.compare:
        compare()
        return

    names = [m for m in args.models.split(",") if m]
    bad = set(names) - set(MODELS)
    if bad:
        sys.exit(f"unknown model(s) {sorted(bad)}; choose from {list(MODELS)}")
    seeds = [int(s) for s in args.seeds.split(",")]
    data = dict(np.load(M.DATA_NPZ, allow_pickle=True))
    info = M.load_info()
    dims = M.dims_from_info(info)
    os.makedirs(OUT_DIR, exist_ok=True)
    print(f"device: {'cuda ' + torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu'}")

    tuned = os.path.join(cfg.RESULT_DIR, "tuning", "main_best_params.json")
    mc_ga = {k: v for k, v in json.load(open(tuned))["best_params"].items() if k in M.MODEL_CFG} \
        if os.path.exists(tuned) else {}
    ga_par = M.count_params(M.GenerativeAURORA(dims, mc_ga))
    for name in names:
        cls = MODELS[name]
        run = f"base_{name}"
        n_par = M.count_params(cls(dims, {}))
        print(f"\n######## {run}: {cls.__name__}, {n_par:,} parameters "
              f"(GenerativeAURORA tuned: {ga_par:,})")
        tc = dict(TR.TRAIN_CFG)

        # 1. equal tuning budget: learning-rate search on val (seed 0)
        lr_file = os.path.join(OUT_DIR, f"{run}_lr_search.json")
        if args.no_lr_search:
            best_lr = tc["lr"]
        elif os.path.exists(lr_file):
            best_lr = json.load(open(lr_file))["best_lr"]
            print(f"learning rate from earlier search: {best_lr}")
        else:
            res = {}
            for lr in LR_GRID:
                s = TR.train_one(data, info, "main", 0, {}, dict(tc, lr=lr, epochs=150, patience=6),
                                 os.path.join(cfg.CKPT_DIR, f"{run}_lrsearch", f"lr{lr:g}"),
                                 log_prefix=f"[{name} lr={lr:g}] ", quiet=True,
                                 model_fn=lambda d, mc: cls(d, mc))
                res[lr] = s["best_val_crps"]
                print(f"  lr {lr:g}: val CRPS {s['best_val_crps']:.4f}")
            best_lr = min(res, key=res.get)
            json.dump(dict(grid=LR_GRID, val_crps={str(k): v for k, v in res.items()},
                           best_lr=best_lr, selection_split="val", seed=0), open(lr_file, "w"), indent=2)
            print(f"  -> chosen lr {best_lr:g}")

        # 2. 5 seeds with the chosen learning rate
        for seed in seeds:
            run_dir = os.path.join(cfg.CKPT_DIR, run, f"seed{seed}")
            if os.path.exists(os.path.join(run_dir, "summary.json")):
                print(f"[{name} seed {seed}] already trained - skipping")
            else:
                s = TR.train_one(data, info, "main", seed, {}, dict(tc, lr=best_lr), run_dir,
                                 log_prefix=f"[{name} seed {seed}] ", quiet=True,
                                 model_fn=lambda d, mc: cls(d, mc))
                print(f"[{name} seed {seed}] best val CRPS {s['best_val_crps']:.4f} "
                      f"at epoch {s['best_epoch']} ({s['minutes']} min)")
            for split in ["cal", "val"]:
                if not os.path.exists(os.path.join(SCEN_DIR, run, f"seed{seed}_{split}.npz")):
                    generate(cls, run, seed, split, data)

        # 3. identical calibration + evaluation pipeline
        for script in ["7_calibrate.py", "8_evaluate.py"]:
            subprocess.run([sys.executable, os.path.join(HERE, script), "--run", run,
                            "--seeds", ",".join(map(str, seeds))], check=False)

    compare()


if __name__ == "__main__":
    main()