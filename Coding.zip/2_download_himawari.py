"""
GenerativeAURORA v2 - 2_download_himawari.py
============================================
Downloads NSRDB Himawari PSM v3 data (2016-2020) for every site in the
registry (1_config.py), one site-year per request, exactly as NREL serves it.

Design:
  - Raw files are saved UNTOUCHED: Dataset/raw/himawari/<site_id>/<year>.csv
    (all cleaning happens later in 3_quality_control.py, never here)
  - Resumable: files that already exist and pass the check are skipped,
    so you can stop it any time and run again.
  - Provenance: every file's NSRDB header (Source, Version, Location ID,
    returned lat/lon, elevation, time zone), md5, row count and the distance
    between the requested and the returned pixel are written to
    Dataset/metadata/download_log.csv  -> this is what answers
    "which product exactly?" for reviewers.
  - The API key is read from the environment and never written anywhere.

Usage (VSCode terminal, in the GenerativeAURORA_v2 folder):
    python 2_download_himawari.py --test          # 1 site, 1 year: try this first
    python 2_download_himawari.py                 # everything (~135 files)
    python 2_download_himawari.py --sites ID_JKT,ID_DPS --years 2019,2020
    python 2_download_himawari.py --dry-run       # show requests, download nothing
"""

import os
import csv
import sys
import math
import time
import hashlib
import argparse
import importlib
from datetime import datetime

import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
cfg = importlib.import_module("1_config")

LOG_FIELDS = ["site_id", "year", "status", "file", "md5", "n_rows", "expected_rows",
              "req_lat", "req_lon", "ret_lat", "ret_lon", "offset_km", "elevation_m",
              "location_id", "source", "version", "time_zone", "local_time_zone",
              "minute_values", "interval_min", "utc", "host", "downloaded_at", "message"]


def expected_rows(year):
    leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    days = 366 if (leap and cfg.LEAP_DAY) else 365
    return days * 24 * 60 // cfg.INTERVAL_MIN


def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def parse_nsrdb_csv(text):
    """NSRDB format: line1 = metadata keys, line2 = metadata values,
    line3 = column header, then data rows."""
    text = text.lstrip("\ufeff")
    lines = text.splitlines()
    if len(lines) < 4 or not lines[0].startswith("Source"):
        raise ValueError("not an NSRDB CSV (first line: %r)" % (lines[0][:120] if lines else ""))
    meta = dict(zip([k.strip() for k in next(csv.reader([lines[0]]))],
                    [v.strip() for v in next(csv.reader([lines[1]]))]))
    header = [h.strip() for h in next(csv.reader([lines[2]]))]
    rows = [r for r in csv.reader(lines[3:]) if r]
    if not rows:
        raise ValueError("NSRDB CSV contains no data rows")
    bad_widths = [i + 4 for i, row in enumerate(rows) if len(row) != len(header)]
    if bad_widths:
        raise ValueError(f"CSV row width differs from header on line(s) {bad_widths[:5]}")
    missing = [c for c in cfg.REQUIRED_COLUMNS if c not in header]
    if missing:
        raise ValueError(f"CSV is missing required columns {missing}; got {header}")
    minutes = sorted({r[header.index("Minute")] for r in rows})
    return meta, header, rows, minutes


def check_existing(path, year):
    """Return (ok, meta, header, rows, minutes, text) for an existing file."""
    try:
        with open(path, encoding="utf-8") as f:
            text = f.read()
        meta, header, rows, minutes = parse_nsrdb_csv(text)
        return len(rows) == expected_rows(year), meta, header, rows, minutes, text
    except Exception:
        return False, None, None, None, None, None


def request_csv(site, year, key, email):
    params = {
        "api_key": key,
        "wkt": f"POINT({site['lon']} {site['lat']})",   # WKT order: lon lat
        "attributes": ",".join(cfg.ATTRIBUTES),
        "names": str(year),
        "interval": str(cfg.INTERVAL_MIN),
        "utc": "true" if cfg.UTC else "false",
        "leap_day": "true" if cfg.LEAP_DAY else "false",
        "email": email,
    }
    last = ""
    for attempt in range(1, cfg.MAX_RETRIES + 1):
        for host in cfg.API_HOSTS:
            try:
                r = requests.get(host + cfg.API_PATH, params=params, timeout=180)
            except requests.RequestException as e:
                last = f"{host}: {type(e).__name__}"
                continue                      # try the other host
            body = r.text.lstrip("\ufeff")
            if r.status_code == 200 and body.startswith("Source"):
                return body, host
            # Do not print the request URL: it contains the API key.
            last = f"{host}: HTTP {r.status_code} {body[:200].strip()}"
            if r.status_code in (400, 401, 403):
                return None, last             # bad request / bad key: no retry helps
            # 404 / 429 / 5xx / unexpected body -> try the next host
        if attempt < cfg.MAX_RETRIES:
            wait = min(60, 5 * 2 ** (attempt - 1))
            print(f"      retry {attempt}/{cfg.MAX_RETRIES} in {wait}s ({last[:100]})")
            time.sleep(wait)
    return None, last


def log_entry(site, year, status, path="", text=None, meta=None, rows=None,
              minutes=None, host="", message=""):
    e = {k: "" for k in LOG_FIELDS}
    e.update(site_id=site["site_id"], year=year, status=status, file=path,
             expected_rows=expected_rows(year), req_lat=site["lat"], req_lon=site["lon"],
             interval_min=cfg.INTERVAL_MIN, utc=cfg.UTC, host=host, message=message,
             downloaded_at=datetime.now().isoformat(timespec="seconds"))
    if text is not None:
        e["md5"] = hashlib.md5(text.encode("utf-8")).hexdigest()
    if rows is not None:
        e["n_rows"] = len(rows)
    if minutes is not None:
        e["minute_values"] = "|".join(minutes)
    if meta:
        try:
            rl, ro = float(meta.get("Latitude")), float(meta.get("Longitude"))
            e.update(ret_lat=rl, ret_lon=ro,
                     offset_km=round(haversine_km(site["lat"], site["lon"], rl, ro), 2))
        except (TypeError, ValueError):
            pass
        e.update(elevation_m=meta.get("Elevation", ""), location_id=meta.get("Location ID", ""),
                 source=meta.get("Source", ""), version=meta.get("Version", ""),
                 time_zone=meta.get("Time Zone", ""),
                 local_time_zone=meta.get("Local Time Zone", ""))
    return e


def write_log(entries):
    # merge with the previous log: latest entry per (site, year) wins
    old = {}
    if os.path.exists(cfg.DOWNLOAD_LOG_CSV):
        with open(cfg.DOWNLOAD_LOG_CSV, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                old[(r["site_id"], str(r["year"]))] = r
    for e in entries:
        old[(e["site_id"], str(e["year"]))] = e
    with open(cfg.DOWNLOAD_LOG_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=LOG_FIELDS)
        w.writeheader()
        for k in sorted(old):
            w.writerow({f: old[k].get(f, "") for f in LOG_FIELDS})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sites", help="comma-separated site_ids (default: all)")
    ap.add_argument("--years", help="comma-separated years (default: all)")
    ap.add_argument("--test", action="store_true", help="download 1 site x 1 year only")
    ap.add_argument("--dry-run", action="store_true", help="list requests, download nothing")
    ap.add_argument("--force", action="store_true", help="re-download existing files")
    args = ap.parse_args()

    cfg.ensure_dirs()
    sites = cfg.load_sites()
    problems, _ = cfg.validate_sites(sites)
    if problems:
        sys.exit("Fix the site registry first (run python 1_config.py):\n  " + "\n  ".join(problems))
    if args.sites:
        want = set(args.sites.split(","))
        sites = [s for s in sites if s["site_id"] in want]
        missing = want - {s["site_id"] for s in sites}
        if missing:
            sys.exit(f"Unknown site_id(s): {sorted(missing)}")
    years = [int(y) for y in args.years.split(",")] if args.years else cfg.YEARS
    bad = [y for y in years if y not in cfg.YEARS]
    if bad:
        sys.exit(f"Years {bad} are outside the product range {cfg.YEARS}")
    if args.test:
        pick = [s for s in sites if s["site_id"] == cfg.TEST_SITE] or sites[:1]
        sites, years = pick[:1], years[-1:]

    jobs = [(s, y) for s in sites for y in years]
    print(f"{cfg.PRODUCT}: {len(jobs)} site-years "
          f"({len(sites)} sites x {len(years)} years), {cfg.INTERVAL_MIN}-min")

    if args.dry_run:
        for s, y in jobs:
            print(f"  {s['site_id']:8s} {y}  POINT({s['lon']} {s['lat']})  {s['name']}")
        return

    key, email = cfg.get_credentials(required=True)
    entries, n_ok, n_skip, n_fail = [], 0, 0, 0
    t0 = time.time()

    for i, (s, y) in enumerate(jobs, 1):
        site_dir = os.path.join(cfg.RAW_DIR, s["site_id"])
        os.makedirs(site_dir, exist_ok=True)
        path = os.path.join(site_dir, f"{y}.csv")
        tag = f"[{i:3d}/{len(jobs)}] {s['site_id']} {y} ({s['name']})"

        if os.path.exists(path) and not args.force:
            ok, meta, header, rows, minutes, text = check_existing(path, y)
            if ok:
                entries.append(log_entry(s, y, "exists", path, text, meta, rows, minutes))
                n_skip += 1
                print(f"{tag}: already downloaded, OK")
                continue
            print(f"{tag}: existing file incomplete -> re-downloading")

        text, host_or_err = request_csv(s, y, key, email)
        time.sleep(cfg.REQUEST_PAUSE_S)
        if text is None:
            entries.append(log_entry(s, y, "failed", message=host_or_err))
            n_fail += 1
            print(f"{tag}: FAILED  {host_or_err[:150]}")
            continue
        try:
            meta, header, rows, minutes = parse_nsrdb_csv(text)
        except ValueError as e:
            entries.append(log_entry(s, y, "failed", host=host_or_err, message=str(e)))
            n_fail += 1
            print(f"{tag}: FAILED  {e}")
            continue

        tmp = path + ".part"                 # atomic write: no half files if stopped
        with open(tmp, "w", encoding="utf-8", newline="") as f:
            f.write(text)
        os.replace(tmp, path)
        status = "ok" if len(rows) == expected_rows(y) else "row_count_mismatch"
        e = log_entry(s, y, status, path, text, meta, rows, minutes, host_or_err)
        entries.append(e)
        n_ok += 1
        print(f"{tag}: {status}  rows={len(rows)}  v{meta.get('Version', '?')}  "
              f"pixel {e['ret_lat']},{e['ret_lon']} ({e['offset_km']} km away)  "
              f"elev {meta.get('Elevation', '?')} m  TZ {meta.get('Time Zone', '?')}")
        if i % 10 == 0:
            write_log(entries)   # save progress regularly

    write_log(entries)
    print("=" * 70)
    print(f"done in {time.time() - t0:.0f}s: downloaded {n_ok}, already present {n_skip}, "
          f"failed {n_fail}")
    print(f"provenance log: {cfg.DOWNLOAD_LOG_CSV}")

    # Consistency summary across everything logged so far
    with open(cfg.DOWNLOAD_LOG_CSV, newline="", encoding="utf-8") as f:
        log = list(csv.DictReader(f))
    good = [r for r in log if r["status"] in ("ok", "exists")]
    versions = sorted({r["version"] for r in good})
    mins = sorted({r["minute_values"] for r in good})
    far = [r for r in good if r["offset_km"] and float(r["offset_km"]) > 3]
    print(f"versions in data : {versions}  {'(single product - good)' if len(versions) == 1 else '!! MIXED'}")
    print(f"minute stamps    : {mins}  {'(consistent)' if len(mins) == 1 else '!! MIXED'}")
    if far:
        print("pixels > 3 km from requested point (check coastline sites):")
        for r in far:
            print(f"  {r['site_id']} {r['year']}: {r['offset_km']} km")
    if n_fail:
        print("Re-run the same command to retry failed site-years.")


if __name__ == "__main__":
    main()