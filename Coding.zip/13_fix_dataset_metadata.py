"""
GenerativeAURORA v2 - 13_fix_dataset_metadata.py
One-off correction of a DOCUMENTATION error in aurora_dataset.json.

The file recorded the satellite-cloud-class regime rule (clear >= 50 %, overcast
>= 70 % thick cloud), but with USE_CLOUD_FEATURES = False the dataset builder
actually labelled regimes by daily mean k_c (Clear >= 0.85, Overcast <= 0.40).
Only the JSON text is corrected. aurora_dataset.npz (which every model was
trained and evaluated on, and whose md5 is stored in each training summary) is
NOT opened for writing; its md5 is printed before and after to prove it.
Nothing reads 'regime_rule'; no result changes.
"""
import os
import sys
import json
import shutil
import hashlib
import importlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
B = importlib.import_module("4_build_dataset")


def md5(p):
    h = hashlib.md5()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


npz_before = md5(B.OUT_NPZ)
info = json.load(open(B.OUT_JSON, encoding="utf-8"))
if info.get("use_cloud_features"):
    sys.exit("use_cloud_features is True: the recorded cloud-class rule is correct, nothing to fix")
backup = B.OUT_JSON + ".before_regime_fix"
if not os.path.exists(backup):
    shutil.copy2(B.OUT_JSON, backup)
print("old regime_rule:", info.get("regime_rule"))
info["regime_rule"] = dict(source="daily_mean_valid_kc", clear_kc_min=B.REGIME_KC_CLEAR,
                           overcast_kc_max=B.REGIME_KC_OVERCAST)
info["metadata_note"] = ("regime_rule corrected on documentation grounds only; it previously "
                         "showed the unused cloud-class rule. Dataset arrays unchanged.")
with open(B.OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(info, f, indent=2)
print("new regime_rule:", info["regime_rule"])
print(f"backup of the old file : {backup}")
npz_after = md5(B.OUT_NPZ)
print(f"aurora_dataset.npz md5 : {npz_before} -> {npz_after}  "
      f"({'UNCHANGED' if npz_before == npz_after else '!! CHANGED'})")