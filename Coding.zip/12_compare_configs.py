"""
GenerativeAURORA v2 - 12_compare_configs.py
Read-only check: do two runs differ ONLY in the settings we claim?
Reads each seed's best.pt (model config, dims, experiment, seed) and
summary.json (training settings, dataset fingerprint), never runs a model.

    python 12_compare_configs.py                      # main_tuned vs main_tuned_linear
    python 12_compare_configs.py main_small main_tuned
"""
import os
import sys
import json
import glob
import importlib

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
cfg = importlib.import_module("1_config")

# differ by design between runs / seeds; reported but not counted as a confound
EXPECTED = {"best_epoch", "best_val_crps", "best_val_loss", "minutes", "epoch", "time",
            "timestamp", "finished", "created", "run_dir", "stopped_epoch", "history",
            "name", "tag"}
TREATMENT = {"schedule"}   # the ONLY intended difference; beta_start/beta_end must match


def flatten(d, prefix=""):
    out = {}
    for k, v in (d or {}).items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        else:
            out[key] = v if isinstance(v, (int, float, str, bool, type(None))) else str(v)
    return out


def load(run, seed):
    d = os.path.join(cfg.CKPT_DIR, run, f"seed{seed}")
    ck = torch.load(os.path.join(d, "best.pt"), map_location="cpu", weights_only=False)
    info = {"model": ck.get("mc"), "dims": ck.get("dims"),
            "experiment": ck.get("experiment"), "seed": ck.get("seed"), "epoch": ck.get("epoch"),
            "n_params": sum(v.numel() for v in ck["state_dict"].values())}
    s = os.path.join(d, "summary.json")
    if os.path.exists(s):
        info["summary"] = json.load(open(s))
    return flatten(info)


def main():
    a, b = (sys.argv[1:3] if len(sys.argv) >= 3 else ("main_tuned", "main_tuned_linear"))
    def seeds_of(r):
        return sorted(int(os.path.basename(p)[4:]) for p in glob.glob(os.path.join(cfg.CKPT_DIR, r, "seed*"))
                      if os.path.exists(os.path.join(p, "best.pt")))
    seeds, seeds_b = seeds_of(a), seeds_of(b)
    print(f"comparing '{a}' vs '{b}', seeds {seeds} / {seeds_b}\n")
    confounds, treatment_seen = set(), False
    if seeds != seeds_b:
        confounds.add(f"seed_sets_differ_{seeds}_vs_{seeds_b}")
        seeds = sorted(set(seeds) & set(seeds_b))
    for s in seeds:
        A, B = load(a, s), load(b, s)
        MISSING = object()
        diff = {k for k in set(A) | set(B) if A.get(k, MISSING) != B.get(k, MISSING)}
        treatment = sorted(k for k in diff if k.split(".")[-1] in TREATMENT)
        diff -= set(treatment)
        print(f"seed {s}:")
        required = ("model.schedule", "summary.model_cfg.schedule")
        if any(k not in A or k not in B for k in required):
            confounds.add(f"seed{s}_schedule_metadata_missing")
        elif (a, b) == ("main_tuned", "main_tuned_linear") and not all(
                A[k] == "cosine" and B[k] == "linear" for k in required):
            confounds.add(f"seed{s}_schedule_values_unexpected")
        elif any(A[k] == B[k] for k in required):
            confounds.add(f"seed{s}_schedule_identical")
        else:
            treatment_seen = True
        for k in treatment:
            print(f"   TREATMENT {k:44s} {A.get(k)!s:>25}  vs  {B.get(k)!s}")
        unexpected = sorted(k for k in diff if k.split(".")[-1] not in EXPECTED)
        expected = sorted(k for k in diff if k.split(".")[-1] in EXPECTED)
        for k in unexpected:
            print(f"   DIFFERS  {k:45s} {A.get(k)!s:>25}  vs  {B.get(k)!s}")
        print(f"   (differs by design: {', '.join(expected) or 'none'})")
        confounds |= set(unexpected)
    print("\nother settings that differ (possible confounds):")
    print("   " + (", ".join(sorted(confounds)) or "none"))
    only_schedule = treatment_seen and not confounds
    print("\nVERDICT:", "only the noise schedule differs -> controlled ablation"
          if only_schedule else "check the list above before calling it a controlled ablation")


if __name__ == "__main__":
    main()