"""
GenerativeAURORA v2 - 5_model.py
================================
Conditional denoising diffusion model (DDPM, Ho et al. 2020) that generates
full-day trajectories of the clear-sky index k_c for day D.

Architecture
  Condition encoders (everything known at issue time, see 4_build_dataset.py)
    PastEncoder   day D-1, 16 h x Fp  -> Conv1d x2 + GRU
                  gives a per-hour sequence (aligned to the same clock hour of
                  day D) and a global summary vector
    HistEncoder   7 daily k_c means + missing-day mask -> MLP
    GeoEncoder    lat, lon, elevation, monthly k_c climatology -> MLP
                  (replaces the Paper 1 site-ID embedding: works for unseen sites)
    Future geometry (cos zenith, hour angle, day of year) is concatenated to
    the U-Net input at every hour.
  Denoiser: 1D U-Net, 3 levels (16 -> 8 -> 4 hours), residual blocks with
    FiLM conditioning on [diffusion-step embedding + condition vector],
    self-attention at the bottleneck, skip connections.
  Diffusion: T steps, linear (Ho et al. 2020) or cosine (Nichol & Dhariwal
    2021) beta schedule, epsilon prediction.
  Loss: MSE between true and predicted noise ONLY on hours with m_y = 1
    (night and excluded hours never contribute - fixes the Paper 1 padding bug).
  Sampling: DDIM (Song et al. 2021) with S steps; eta = 1 reproduces DDPM-like
    stochastic sampling, eta = 0 is deterministic given the initial noise.
    Hours with the sun below 5 deg are set to k_c = 0 after sampling.

Run directly for a self-test (uses your real dataset if it exists):
    python 5_model.py
"""

import os
import sys
import json
import math
import time
import importlib

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
cfg = importlib.import_module("1_config")

DATA_NPZ = os.path.join(cfg.PROC_DIR, "aurora_dataset.npz")
DATA_JSON = os.path.join(cfg.PROC_DIR, "aurora_dataset.json")

# Default hyperparameters. Starting points from the literature; 6_train.py
# tunes the important ones on the validation split (never on cal/test).
MODEL_CFG = dict(
    base_ch=64,            # U-Net width at full resolution
    ch_mult=(1, 2, 4),     # 64 -> 128 -> 256 channels over 3 levels
    past_hidden=128,       # PastEncoder width
    cond_dim=128,          # size of the global condition vector
    emb_dim=256,           # FiLM embedding size (step + condition)
    dropout=0.1,
    attn_heads=4,
    T=200,                 # diffusion steps
    schedule="cosine",     # "cosine" (Nichol & Dhariwal 2021) or "linear" (Ho et al. 2020)
    beta_start=1e-4,       # linear schedule only: Ho et al. 2020 values for T=1000,
    beta_end=0.02,         # rescaled by 1000/T in make_betas
)


# ----------------------------------------------------------------------------
# Noise schedules
# ----------------------------------------------------------------------------
def make_betas(schedule, T, beta_start=1e-4, beta_end=0.02):
    if schedule == "linear":
        # Ho et al. (2020) values are defined for T = 1000; scale them by 1000/T
        # (as in Nichol & Dhariwal 2021) so the last step is ~pure noise for any T
        sc = 1000.0 / T
        b = torch.linspace(beta_start * sc, min(beta_end * sc, 0.999), T, dtype=torch.float64)
    elif schedule == "cosine":
        s = 0.008
        x = torch.linspace(0, T, T + 1, dtype=torch.float64)
        ab = torch.cos(((x / T) + s) / (1 + s) * math.pi / 2) ** 2
        ab = ab / ab[0]
        b = (1 - ab[1:] / ab[:-1]).clamp(1e-8, 0.999)
    else:
        raise ValueError(f"unknown schedule {schedule!r}")
    return b.float()


def sinusoidal(t, dim):
    half = dim // 2
    freqs = torch.exp(-math.log(10000) * torch.arange(half, device=t.device) / half)
    a = t.float()[:, None] * freqs[None]
    return torch.cat([a.sin(), a.cos()], dim=-1)


# ----------------------------------------------------------------------------
# Building blocks
# ----------------------------------------------------------------------------
class PastEncoder(nn.Module):
    def __init__(self, f_in, hidden):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(f_in, hidden, 3, padding=1), nn.SiLU(),
            nn.Conv1d(hidden, hidden, 3, padding=1), nn.SiLU())
        self.gru = nn.GRU(hidden, hidden, batch_first=True)
        self.norm = nn.LayerNorm(hidden)

    def forward(self, x):                      # x [B, L, F]
        self.gru.flatten_parameters()          # keep cuDNN weights contiguous (EMA copy)
        h = self.conv(x.transpose(1, 2))       # [B, H, L]
        seq, hn = self.gru(h.transpose(1, 2))  # seq [B, L, H]
        return seq.transpose(1, 2), self.norm(hn[-1])


def mlp(i, h, o, dropout=0.0):
    return nn.Sequential(nn.Linear(i, h), nn.SiLU(), nn.Dropout(dropout), nn.Linear(h, o))


class ResBlock1d(nn.Module):
    def __init__(self, cin, cout, emb_dim, dropout):
        super().__init__()
        self.n1 = nn.GroupNorm(8, cin)
        self.c1 = nn.Conv1d(cin, cout, 3, padding=1)
        self.film = nn.Linear(emb_dim, 2 * cout)
        self.n2 = nn.GroupNorm(8, cout)
        self.drop = nn.Dropout(dropout)
        self.c2 = nn.Conv1d(cout, cout, 3, padding=1)
        self.skip = nn.Conv1d(cin, cout, 1) if cin != cout else nn.Identity()

    def forward(self, x, e):
        h = self.c1(F.silu(self.n1(x)))
        scale, shift = self.film(F.silu(e)).chunk(2, dim=-1)
        h = self.n2(h) * (1 + scale[..., None]) + shift[..., None]
        h = self.c2(self.drop(F.silu(h)))
        return h + self.skip(x)


class Attn1d(nn.Module):
    def __init__(self, ch, heads):
        super().__init__()
        self.norm = nn.GroupNorm(8, ch)
        self.attn = nn.MultiheadAttention(ch, heads, batch_first=True)

    def forward(self, x):
        h = self.norm(x).transpose(1, 2)
        h, _ = self.attn(h, h, h, need_weights=False)
        return x + h.transpose(1, 2)


class UNet1d(nn.Module):
    def __init__(self, in_ch, base, mult, emb_dim, dropout, heads):
        super().__init__()
        chs = [base * m for m in mult]
        self.stem = nn.Conv1d(in_ch, base, 3, padding=1)
        self.down_res, self.down_samp = nn.ModuleList(), nn.ModuleList()
        prev = base
        for i, c in enumerate(chs):
            self.down_res.append(ResBlock1d(prev, c, emb_dim, dropout))
            prev = c
            if i < len(chs) - 1:
                self.down_samp.append(nn.Conv1d(c, c, 3, stride=2, padding=1))
        self.mid1 = ResBlock1d(prev, prev, emb_dim, dropout)
        self.mid_attn = Attn1d(prev, heads)
        self.mid2 = ResBlock1d(prev, prev, emb_dim, dropout)
        self.up_res, self.up_samp = nn.ModuleList(), nn.ModuleList()
        for i in reversed(range(len(chs))):
            self.up_res.append(ResBlock1d(prev + chs[i], chs[i], emb_dim, dropout))
            prev = chs[i]
            if i > 0:
                self.up_samp.append(nn.Conv1d(chs[i], chs[i], 3, padding=1))
        self.out = nn.Sequential(nn.GroupNorm(8, prev), nn.SiLU(), nn.Conv1d(prev, 1, 3, padding=1))
        self.levels = len(chs)

    def forward(self, x, e):
        h = self.stem(x)
        skips = []
        for i, res in enumerate(self.down_res):
            h = res(h, e)
            skips.append(h)
            if i < self.levels - 1:
                h = self.down_samp[i](h)
        h = self.mid2(self.mid_attn(self.mid1(h, e)), e)
        for j, res in enumerate(self.up_res):
            h = res(torch.cat([h, skips[self.levels - 1 - j]], dim=1), e)
            if j < self.levels - 1:
                h = self.up_samp[j](F.interpolate(h, scale_factor=2, mode="nearest"))
        return self.out(h).squeeze(1)          # [B, L]


# ----------------------------------------------------------------------------
# GenerativeAURORA
# ----------------------------------------------------------------------------
class GenerativeAURORA(nn.Module):
    def __init__(self, dims, mc=None):
        super().__init__()
        mc = dict(MODEL_CFG, **(mc or {}))
        self.mc, self.dims = mc, dims
        L = dims["L"]
        if L % (2 ** (len(mc["ch_mult"]) - 1)):
            raise ValueError(f"sequence length {L} must be divisible by {2 ** (len(mc['ch_mult']) - 1)}")
        H, C, E = mc["past_hidden"], mc["cond_dim"], mc["emb_dim"]
        self.past_enc = PastEncoder(dims["past"], H)
        self.hist_enc = mlp(2 * dims["hist"], C, C)
        self.geo_enc = mlp(dims["static"], C, C)
        self.cond = mlp(H + 2 * C, C, C, mc["dropout"])
        self.t_mlp = mlp(E, E, E)
        self.fuse = mlp(E + C, E, E)
        self.unet = UNet1d(1 + dims["future"] + H, mc["base_ch"], mc["ch_mult"], E,
                           mc["dropout"], mc["attn_heads"])
        self.sun_idx = dims["sun_idx"]

        betas = make_betas(mc["schedule"], mc["T"], mc["beta_start"], mc["beta_end"])
        ab = torch.cumprod(1 - betas, 0)
        self.register_buffer("betas", betas)
        self.register_buffer("alpha_bar", ab)

    # -- conditioning (computed once per forecast, reused for all steps/samples)
    def encode(self, b):
        seq, glob = self.past_enc(b["x_past"])
        hist = self.hist_enc(torch.cat([b["x_hist"], b["m_hist"]], -1))
        geo = self.geo_enc(b["x_static"])
        vec = self.cond(torch.cat([glob, hist, geo], -1))
        return dict(seq=seq, fut=b["x_future"].transpose(1, 2), vec=vec)

    def eps(self, x_t, t, enc):
        e = self.fuse(torch.cat([self.t_mlp(sinusoidal(t, self.mc["emb_dim"])), enc["vec"]], -1))
        x = torch.cat([x_t[:, None], enc["fut"], enc["seq"]], dim=1)
        return self.unet(x, e)

    # -- training loss: masked epsilon MSE
    def loss(self, b, t=None, noise=None):
        m = b["m_y"]
        # k_c [0,1] -> [-1,1]; masked hours fixed to -1 (k_c = 0) so their stored
        # value can never influence training
        x0 = torch.where(m > 0, 2 * b["y"] - 1, torch.full_like(b["y"], -1.0))
        B = x0.shape[0]
        if t is None:
            t = torch.randint(0, self.mc["T"], (B,), device=x0.device)
        if noise is None:
            noise = torch.randn_like(x0)
        ab = self.alpha_bar[t][:, None]
        x_t = ab.sqrt() * x0 + (1 - ab).sqrt() * noise
        pred = self.eps(x_t, t, self.encode(b))
        return (((pred - noise) ** 2) * m).sum() / m.sum().clamp(min=1.0)

    # -- sampling: K trajectories per forecast
    @torch.no_grad()
    def sample(self, b, K=50, steps=50, eta=1.0, generator=None):
        enc = self.encode(b)
        B, L = b["x_future"].shape[0], self.dims["L"]
        enc = {k: v.repeat_interleave(K, dim=0) for k, v in enc.items()}
        T = self.mc["T"]
        ts = torch.linspace(T - 1, 0, steps, device=enc["vec"].device).round().long()
        x = torch.randn(B * K, L, device=enc["vec"].device, generator=generator)
        for i, t in enumerate(ts):
            ab_t = self.alpha_bar[t].clamp(min=1e-8)
            ab_prev = self.alpha_bar[ts[i + 1]] if i + 1 < len(ts) else torch.ones_like(ab_t)
            e = self.eps(x, t.repeat(B * K), enc)
            x0 = ((x - (1 - ab_t).sqrt() * e) / ab_t.sqrt()).clamp(-1, 1)
            e = (x - ab_t.sqrt() * x0) / (1 - ab_t).sqrt()
            sigma = eta * ((1 - ab_prev) / (1 - ab_t) * (1 - ab_t / ab_prev)).clamp(min=0).sqrt()
            noise = torch.randn(x.shape, device=x.device, generator=generator)
            x = ab_prev.sqrt() * x0 + (1 - ab_prev - sigma ** 2).clamp(min=0).sqrt() * e + sigma * noise
        kc = ((x + 1) / 2).clamp(0, 1).view(B, K, L)
        sun = b["x_future"][:, :, self.sun_idx][:, None, :]
        return kc * sun                                       # [B, K, L], 0 at night


# ----------------------------------------------------------------------------
# Data helpers (used by 6_train.py, 7_calibrate.py, 8_evaluate.py)
# ----------------------------------------------------------------------------
ARRAYS = ["x_past", "x_future", "x_hist", "m_hist", "y", "m_y"]


def load_info():
    with open(DATA_JSON, encoding="utf-8") as f:
        return json.load(f)


def dims_from_info(info, L=16):
    return dict(L=L, past=len(info["past_features"]), future=len(info["future_features"]),
                hist=info["hist_days"], static=len(info["static_features"]),
                sun_idx=info["future_features"].index("sun_up"))


def load_split(data, split, experiment="main", sites=None, exclude_sites=None):
    """Numpy dict for one split. experiment 'main' (test 2020) or 'alt' (test 2019).
    sites / exclude_sites restrict locations (for leave-region-out)."""
    key = "split_main" if experiment == "main" else "split_alt"
    sel = data[key] == split
    if sites is not None:
        sel &= np.isin(data["site_id"], list(sites))
    if exclude_sites is not None:
        sel &= ~np.isin(data["site_id"], list(exclude_sites))
    out = {k: data[k][sel] for k in ARRAYS}
    out["x_static"] = (data["x_static"] if experiment == "main" else data["x_static_alt"])[sel]
    for k in ["date", "site_id", "region", "regime_true", "regime_proxy", "clearsky", "ghi"]:
        out[k] = data[k][sel]
    return out


def to_batch(d, idx, device):
    keys = ARRAYS + ["x_static"]
    return {k: torch.as_tensor(d[k][idx], dtype=torch.float32, device=device) for k in keys}


def crps_ensemble(S, y, m):
    """Masked ensemble CRPS (energy form), averaged over valid hours.
    S [B,K,L] samples, y [B,L] truth, m [B,L] mask. Works for torch or numpy."""
    if isinstance(S, np.ndarray):
        S, y, m = torch.as_tensor(S), torch.as_tensor(y), torch.as_tensor(m)
    K = S.shape[1]
    term1 = (S - y[:, None, :]).abs().mean(1)
    Ss, _ = torch.sort(S, dim=1)
    i = torch.arange(1, K + 1, device=S.device, dtype=S.dtype)[None, :, None]
    term2 = (2.0 / K ** 2) * ((2 * i - K - 1) * Ss).sum(1)      # E|X - X'|
    crps = term1 - 0.5 * term2
    return float((crps * m).sum() / m.sum().clamp(min=1))


def count_params(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)


# ----------------------------------------------------------------------------
# Self-test
# ----------------------------------------------------------------------------
def main():
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"device: {dev}" + (f" ({torch.cuda.get_device_name(0)})" if dev.type == "cuda" else ""))
    torch.manual_seed(0)

    if os.path.exists(DATA_NPZ):
        info = load_info()
        data = np.load(DATA_NPZ, allow_pickle=True)
        d = load_split(data, "train")
        print(f"real dataset: {len(d['y']):,} training samples")
    else:
        print("dataset not found - using random tensors")
        info = dict(past_features=[f"p{i}" for i in range(15)],
                    future_features=["cos_zenith", "sun_up", "ha_sin", "ha_cos", "doy_sin", "doy_cos"],
                    hist_days=7, static_features=[f"s{i}" for i in range(15)])
        n = 256
        d = dict(x_past=np.random.randn(n, 16, 15), x_future=np.random.rand(n, 16, 6),
                 x_hist=np.random.rand(n, 7), m_hist=np.ones((n, 7)),
                 x_static=np.random.randn(n, 15), y=np.random.rand(n, 16),
                 m_y=(np.random.rand(n, 16) > 0.3).astype(float))
    dims = dims_from_info(info)

    for sched in ["cosine", "linear"]:
        m = GenerativeAURORA(dims, dict(schedule=sched)).to(dev)
        ab = m.alpha_bar
        print(f"\n[{sched}] parameters {count_params(m):,}  alpha_bar: t=0 {ab[0]:.4f}, "
              f"t=T/2 {ab[len(ab) // 2]:.4f}, t=T-1 {ab[-1]:.5f}")

    m = GenerativeAURORA(dims).to(dev)
    idx = np.arange(64)
    b = to_batch(d, idx, dev)

    # 1. loss + backward
    loss = m.loss(b)
    loss.backward()
    print(f"\n1. loss on a batch of 64: {loss.item():.4f} (should be ~1 for an untrained model)")
    ok_grad = all(p.grad is not None for p in m.parameters() if p.requires_grad)
    print(f"   every parameter receives a gradient: {ok_grad}")

    # 2. masked positions must not influence the loss
    m.eval()
    t = torch.randint(0, m.mc["T"], (64,), device=dev)
    noise = torch.randn(64, dims["L"], device=dev)
    l1 = m.loss(b, t, noise).item()
    b2 = dict(b)
    b2["y"] = torch.where(b["m_y"] > 0, b["y"], torch.rand_like(b["y"]))   # change masked targets
    l2 = m.loss(b2, t, noise).item()
    print(f"2. loss with masked hours changed: {l1:.6f} vs {l2:.6f}  "
          f"-> {'masked hours ignored' if abs(l1 - l2) < 1e-4 * max(1, abs(l1)) else 'CHECK: mask leaks'}")

    # 3. sampling
    bs = to_batch(d, np.arange(8), dev)
    t0 = time.time()
    s = m.sample(bs, K=50, steps=50)
    dt = time.time() - t0
    sun = bs["x_future"][:, :, dims["sun_idx"]]
    night_zero = bool(((s * (1 - sun[:, None, :])).abs().max() == 0).item())
    print(f"3. sample shape {tuple(s.shape)} (days, scenarios, hours), range "
          f"[{s.min().item():.3f}, {s.max().item():.3f}], night hours = 0: {night_zero}, "
          f"{dt:.2f}s for 8 days x 50 scenarios")

    # 4. training speed
    m.train()
    opt = torch.optim.AdamW(m.parameters(), lr=2e-4)
    bb = to_batch(d, np.arange(min(256, len(d["y"]))), dev)
    for _ in range(3):
        opt.zero_grad(); m.loss(bb).backward(); opt.step()
    if dev.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.time()
    for _ in range(20):
        opt.zero_grad(); m.loss(bb).backward(); opt.step()
    if dev.type == "cuda":
        torch.cuda.synchronize()
    per = (time.time() - t0) / 20
    n_train = len(d["y"])
    print(f"4. {per * 1000:.1f} ms per step (batch 256) -> ~{per * n_train / 256:.1f} s per epoch "
          f"on {n_train:,} samples")
    print("\nSelf-test finished.")


if __name__ == "__main__":
    main()