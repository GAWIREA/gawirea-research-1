"""
GenerativeAURORA v2 - 1_config.py
=================================
Single source of truth for the whole pipeline: paths, site registry, data
product, time splits, seeds and credentials. Every other script (2_, 3_, ...)
imports this file, so a setting is changed in ONE place only.

Run it directly to check the setup:
    python 1_config.py

What it does when run:
  - creates the project folders
  - validates the site registry (unique ids, coordinates inside the
    Himawari domain, every region has >= 2 sites for leave-region-out)
  - writes Dataset/metadata/site_registry.csv (goes into the paper's Table 1)
  - prints the time split and checks whether credentials and the GPU are ready

Adding more locations (e.g. a Gawirea PV plant): create
Dataset/metadata/sites_custom.csv with columns
    site_id,name,region,lat,lon
and they are appended to the registry automatically. No code change needed.
"""

import os
import sys
import csv
import random
import math
from datetime import date

# ----------------------------------------------------------------------------
# 1. Paths  (everything is relative to the folder this file lives in)
# ----------------------------------------------------------------------------
ROOT = os.path.dirname(os.path.abspath(__file__))

DATA_DIR = os.path.join(ROOT, "Dataset")
RAW_DIR = os.path.join(DATA_DIR, "raw", "himawari")      # untouched API files
META_DIR = os.path.join(DATA_DIR, "metadata")             # registry, provenance
PROC_DIR = os.path.join(DATA_DIR, "processed")            # QC'd / model-ready
CKPT_DIR = os.path.join(ROOT, "Checkpoints")
RESULT_DIR = os.path.join(ROOT, "Results")
FIG_DIR = os.path.join(ROOT, "Figures")
LOG_DIR = os.path.join(ROOT, "Logs")

ALL_DIRS = [DATA_DIR, RAW_DIR, META_DIR, PROC_DIR, CKPT_DIR, RESULT_DIR, FIG_DIR, LOG_DIR]

SITE_REGISTRY_CSV = os.path.join(META_DIR, "site_registry.csv")
CUSTOM_SITES_CSV = os.path.join(META_DIR, "sites_custom.csv")
DOWNLOAD_LOG_CSV = os.path.join(META_DIR, "download_log.csv")


def ensure_dirs():
    for d in ALL_DIRS:
        os.makedirs(d, exist_ok=True)


# ----------------------------------------------------------------------------
# 2. Data product  (verified against NREL developer docs, himawari-download)
#    One product, one version, one time convention for EVERY site.
# ----------------------------------------------------------------------------
PRODUCT = "NSRDB Himawari PSM v3 (2016-2020)"
# NREL was renamed NLR (National Laboratory of the Rockies). The docs page is
# served from developer.nrel.gov but names NLR; old scripts used developer.nlr.gov.
# Try them in order: a 404/5xx/connection error moves to the next host,
# a 400/401/403 (bad request or key) stops immediately.
API_HOSTS = ["https://developer.nlr.gov", "https://developer.nrel.gov"]
API_PATH = "/api/nsrdb/v2/solar/himawari-download.csv"

YEARS = [2016, 2017, 2018, 2019, 2020]   # full extent of the product
INTERVAL_MIN = 60                         # 10, 30 or 60 available
UTC = False                               # False = local standard time, no DST
LEAP_DAY = True                           # keep Feb 29 (2016, 2020)

# Attribute names exactly as listed in the API documentation.
ATTRIBUTES = [
    "ghi", "dni", "dhi",
    "clearsky_ghi", "clearsky_dni", "clearsky_dhi",
    "solar_zenith_angle",
    "air_temperature", "relative_humidity", "dew_point",
    "surface_pressure", "wind_speed", "wind_direction",
    "total_precipitable_water", "aod", "surface_albedo",
    "cloud_type",        # satellite cloud class: regime labels NOT derived from GHI
    "fill_flag",         # NSRDB gap-fill flag: used in 3_quality_control.py
]

# Columns the raw CSV must contain (NSRDB header names) - checked after download
REQUIRED_COLUMNS = ["Year", "Month", "Day", "Hour", "Minute", "GHI", "DNI", "DHI",
                    "Clearsky GHI", "Solar Zenith Angle", "Cloud Type", "Fill Flag"]

TEST_SITE = "ID_JKT"      # --test downloads this site (central, surely covered)

REQUEST_PAUSE_S = 1.2     # API limit for .csv requests: max 1 per second
MAX_RETRIES = 5


# ----------------------------------------------------------------------------
# 3. Site registry
#    Approximate city-centre coordinates. The API returns the nearest 2-km
#    pixel; the returned lat/lon/elevation are logged by 2_download_himawari.py
#    and those logged values are the ones used by the model.
#    region = unit for leave-one-region-out (spatial generalisation test).
# ----------------------------------------------------------------------------
SITES = [
    # --- Sumatra -----------------------------------------------------------
    dict(site_id="ID_BNA", name="Banda Aceh",    region="Sumatra",       lat=5.548,  lon=95.323),
    dict(site_id="ID_MDN", name="Medan",         region="Sumatra",       lat=3.595,  lon=98.672),
    dict(site_id="ID_PDG", name="Padang",        region="Sumatra",       lat=-0.947, lon=100.417),
    dict(site_id="ID_PLM", name="Palembang",     region="Sumatra",       lat=-2.976, lon=104.775),
    # --- Java ----------------------------------------------------------------
    dict(site_id="ID_JKT", name="Jakarta",       region="Java",          lat=-6.200, lon=106.817),
    dict(site_id="ID_BDG", name="Bandung",       region="Java",          lat=-6.917, lon=107.619),
    dict(site_id="ID_SMG", name="Semarang",      region="Java",          lat=-6.967, lon=110.417),
    dict(site_id="ID_SUB", name="Surabaya",      region="Java",          lat=-7.250, lon=112.750),
    # --- Kalimantan ----------------------------------------------------------
    dict(site_id="ID_PNK", name="Pontianak",     region="Kalimantan",    lat=-0.026, lon=109.343),
    dict(site_id="ID_PKY", name="Palangka Raya", region="Kalimantan",    lat=-2.208, lon=113.917),
    dict(site_id="ID_BJM", name="Banjarmasin",   region="Kalimantan",    lat=-3.317, lon=114.590),
    dict(site_id="ID_BPN", name="Balikpapan",    region="Kalimantan",    lat=-1.268, lon=116.831),
    # --- Sulawesi ------------------------------------------------------------
    dict(site_id="ID_MDC", name="Manado",        region="Sulawesi",      lat=1.474,  lon=124.842),
    dict(site_id="ID_PLW", name="Palu",          region="Sulawesi",      lat=-0.898, lon=119.870),
    dict(site_id="ID_KDI", name="Kendari",       region="Sulawesi",      lat=-3.972, lon=122.515),
    dict(site_id="ID_UPG", name="Makassar",      region="Sulawesi",      lat=-5.147, lon=119.432),
    # --- Bali & Nusa Tenggara -----------------------------------------------
    dict(site_id="ID_DPS", name="Denpasar",      region="Nusa_Tenggara", lat=-8.650, lon=115.217),
    dict(site_id="ID_AMI", name="Mataram",       region="Nusa_Tenggara", lat=-8.583, lon=116.117),
    dict(site_id="ID_BMU", name="Bima",          region="Nusa_Tenggara", lat=-8.460, lon=118.727),
    dict(site_id="ID_KOE", name="Kupang",        region="Nusa_Tenggara", lat=-10.178, lon=123.607),
    # --- Maluku --------------------------------------------------------------
    dict(site_id="ID_TTE", name="Ternate",       region="Maluku",        lat=0.790,  lon=127.384),
    dict(site_id="ID_AMQ", name="Ambon",         region="Maluku",        lat=-3.695, lon=128.181),
    dict(site_id="ID_LUV", name="Tual",          region="Maluku",        lat=-5.633, lon=132.750),
    # --- Papua ---------------------------------------------------------------
    dict(site_id="ID_SOQ", name="Sorong",        region="Papua",         lat=-0.876, lon=131.255),
    dict(site_id="ID_DJJ", name="Jayapura",      region="Papua",         lat=-2.533, lon=140.717),
    dict(site_id="ID_TIM", name="Timika",        region="Papua",         lat=-4.550, lon=136.890),
    dict(site_id="ID_MKQ", name="Merauke",       region="Papua",         lat=-8.493, lon=140.401),
]

# Rough Himawari-8 NSRDB domain check (sanity only; the API is the authority)
DOMAIN = dict(lat_min=-60.0, lat_max=60.0, lon_min=70.0, lon_max=180.0)


def load_sites():
    """Built-in registry + optional Dataset/metadata/sites_custom.csv."""
    sites = [dict(s, source="builtin") for s in SITES]
    if os.path.exists(CUSTOM_SITES_CSV):
        # utf-8-sig: Excel on Windows saves CSVs with a BOM
        with open(CUSTOM_SITES_CSV, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            need = {"site_id", "name", "region", "lat", "lon"}
            have = {c.strip() for c in (reader.fieldnames or [])}
            if not need <= have:
                sys.exit(f"{CUSTOM_SITES_CSV}: needs columns {sorted(need)}, found {sorted(have)}")
            for n, row in enumerate(reader, start=2):
                row = {k.strip(): (v or "").strip() for k, v in row.items() if k}
                if not any(row.values()):
                    continue  # blank line
                try:
                    lat, lon = float(row["lat"]), float(row["lon"])
                except ValueError:
                    sys.exit(f"{CUSTOM_SITES_CSV} line {n}: lat/lon must be numbers "
                             f"(use a dot as decimal separator): {row}")
                sites.append(dict(site_id=row["site_id"], name=row["name"],
                                  region=row["region"], lat=lat, lon=lon, source="custom"))
    return sites


def validate_sites(sites):
    problems = []
    ids = [s["site_id"] for s in sites]
    dup = {i for i in ids if ids.count(i) > 1}
    if dup:
        problems.append(f"duplicate site_id: {sorted(dup)}")
    for s in sites:
        if not (math.isfinite(s["lat"]) and math.isfinite(s["lon"])):
            problems.append(f"{s['site_id']}: latitude/longitude must be finite numbers")
        elif not (DOMAIN["lat_min"] <= s["lat"] <= DOMAIN["lat_max"]
                  and DOMAIN["lon_min"] <= s["lon"] <= DOMAIN["lon_max"]):
            problems.append(f"{s['site_id']} outside the rough Himawari bounding box ({s['lat']}, {s['lon']})")
        if not s["name"].strip() or not s["region"].strip():
            problems.append(f"{s['site_id']}: name and region must be non-empty")
        if any(c in s["site_id"] for c in ' /\\:*?"<>|'):
            problems.append(f"{s['site_id']}: site_id must be a valid folder name")
    regions = {}
    for s in sites:
        regions.setdefault(s["region"], []).append(s["site_id"])
    # A one-site region is valid for prediction/download. It is simply not
    # eligible to be a leave-one-region-out holdout until another site is added.
    return problems, regions


# ----------------------------------------------------------------------------
# 4. Time split  (every split covers BOTH wet and dry seasons)
#    train : 2016-2018 (3 full years)
#    val   : 2019, odd ISO weeks   -> early stopping & hyperparameter tuning
#    cal   : 2019, even ISO weeks  -> conformal calibration ONLY
#    test  : 2020 (full year)      -> touched once, at the very end
#    Weekly blocks (not random days) limit day-to-day dependence between
#    val and cal, while keeping both spread over the whole year.
#    A sample belongs to the split of its FORECAST day D.
# ----------------------------------------------------------------------------
TRAIN_YEARS = [2016, 2017, 2018]
VALCAL_YEAR = 2019
TEST_YEAR = 2020


def split_of(d: date) -> str:
    if d.year in TRAIN_YEARS:
        return "train"
    if d.year == VALCAL_YEAR:
        return "val" if d.isocalendar()[1] % 2 == 1 else "cal"
    if d.year == TEST_YEAR:
        return "test"
    return "unused"


# ----------------------------------------------------------------------------
# 5. Reproducibility
# ----------------------------------------------------------------------------
SEEDS = [0, 1, 2, 3, 4]   # 5 independent training seeds for every model


def set_seed(seed: int):
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import numpy as np
        np.random.seed(seed)
    except ImportError:
        pass
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


# ----------------------------------------------------------------------------
# 6. Credentials  (NEVER hard-code them; read from environment variables)
#    Windows PowerShell, once:
#       setx NREL_API_KEY "your-new-key"
#       setx NREL_EMAIL   "you@example.com"
#    then close and reopen VSCode.
# ----------------------------------------------------------------------------
def _from_windows_user_env(name):
    """setx writes to the registry, but already-open programs (VSCode, Code
    Runner) keep their old environment until restarted. Read the registry
    directly so a fresh setx works immediately."""
    if os.name != "nt":
        return ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as k:
            return str(winreg.QueryValueEx(k, name)[0])
    except OSError:
        return ""


def get_credentials(required=True):
    key = (os.environ.get("NREL_API_KEY", "") or _from_windows_user_env("NREL_API_KEY")).strip()
    email = (os.environ.get("NREL_EMAIL", "") or _from_windows_user_env("NREL_EMAIL")).strip()
    if required and (not key or not email):
        sys.exit("Missing NREL_API_KEY / NREL_EMAIL environment variables.\n"
                 "PowerShell:  setx NREL_API_KEY \"your-key\"\n"
                 "             setx NREL_EMAIL \"you@example.com\"\n"
                 "Then restart VSCode.")
    return key, email


# ----------------------------------------------------------------------------
# Self-check
# ----------------------------------------------------------------------------
def main():
    ensure_dirs()
    sites = load_sites()
    problems, regions = validate_sites(sites)

    print("GenerativeAURORA v2 - configuration check")
    print("=" * 70)
    print(f"Project root : {ROOT}")
    print(f"Product      : {PRODUCT}, years {YEARS[0]}-{YEARS[-1]}, "
          f"{INTERVAL_MIN}-min, {'UTC' if UTC else 'local standard time'}")
    print(f"Sites        : {len(sites)} in {len(regions)} regions")
    for r, members in regions.items():
        suffix = " [single-site region: not eligible for leave-region-out]" if len(members) < 2 else ""
        print(f"  {r:14s} {len(members)}: {', '.join(members)}{suffix}")
    if INTERVAL_MIN not in (10, 30, 60):
        sys.exit("INTERVAL_MIN must be one of 10, 30 or 60.")

    with open(SITE_REGISTRY_CSV, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["site_id", "name", "region", "lat", "lon", "source"])
        w.writeheader()
        for s in sites:
            w.writerow({k: s[k] for k in w.fieldnames})
    print(f"Registry     : {SITE_REGISTRY_CSV}")

    counts = {}
    d = date(2016, 1, 1)
    from datetime import timedelta
    while d <= date(2020, 12, 31):
        k = split_of(d)
        counts[k] = counts.get(k, 0) + 1
        d += timedelta(days=1)
    print("Split (days per site): " + ", ".join(f"{k}={v}" for k, v in counts.items()))

    key, email = get_credentials(required=False)
    print(f"Credentials  : NREL_API_KEY {'set' if key else 'MISSING'}, "
          f"NREL_EMAIL {'set' if email else 'MISSING'}")

    try:
        import torch
        ok = torch.cuda.is_available()
        print(f"PyTorch      : {torch.__version__}, CUDA "
              f"{'OK - ' + torch.cuda.get_device_name(0) if ok else 'NOT available'}")
    except ImportError:
        print("PyTorch      : not installed (needed from 5_model.py onward)")

    if problems:
        print("\nPROBLEMS:")
        for p in problems:
            print("  - " + p)
        sys.exit(1)
    print("\nConfig OK.")


if __name__ == "__main__":
    main()