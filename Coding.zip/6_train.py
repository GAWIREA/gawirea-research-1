"""
GenerativeAURORA v2 - 6_train.py
================================
Trains GenerativeAURORA reproducibly on the GPU.

What it does
  - Trains on the 'train' split, selects the checkpoint on the 'val' split.
    The 'cal' split (conformal calibration) and 'test' split are NEVER touched.
  - Model selection metric: validation CRPS of k_c (probabilistic skill), from
    20 sampled scenarios on a fixed subset of 1,024 validation days, every
    EVAL_EVERY epochs. The validation diffusion loss is logged as well.
  - AdamW + warm-up + cosine learning-rate decay, gradient clipping, and an
    exponential moving average (EMA) of the weights, as in Ho et al. (2020).
    The EMA weights are the ones evaluated and saved.
  - Early stopping when validation CRPS has not improved for PATIENCE evaluations.
  - Saves everything needed to reproduce a run: config, seed, library and GPU
    versions, dataset checksum, per-epoch log, best checkpoint.

Hyperparameters (friend's comment 6)
  Defaults = literature starting points (see 5_model.py MODEL_CFG and TRAIN_CFG
  below). With --tune N, Optuna (TPE sampler, fixed seed) searches N trials on
  the VALIDATION split only and writes the search space, every trial and the
  best values to Results/tuning/. Later runs use them with --params.

Usage (in the GenerativeAURORA_v2 folder)
    python 6_train.py                                   # main experiment, seed 0
    python 6_train.py --seeds 0,1,2,3,4                 # 5 seeds
    python 6_train.py --experiment alt                  # test year 2019 setup
    python 6_train.py --schedule linear --name lin      # schedule ablation
    python 6_train.py --tune 30                         # hyperparameter search
    python 6_train.py --params Results/tuning/main_best_params.json --seeds 0,1,2,3,4
    python 6_train.py --exclude-regions Papua           # used by 10_spatial_holdout.py
"""

import os
import sys
import csv
import json
import time
import copy
import hashlib
import argparse
import platform
import importlib
from datetime import datetime

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
cfg = importlib.import_module("1_config")
M = importlib.import_module("5_model")

TRAIN_CFG = dict(
    lr=2e-4,              # AdamW learning rate (DDPM literature: 1e-4 to 2e-4)
    weight_decay=1e-4,
    batch_size=256,
    epochs=300,           # upper limit; early stopping usually ends earlier
    warmup_steps=500,
    grad_clip=1.0,
    ema_decay=0.999,
    eval_every=5,         # epochs between validation-CRPS evaluations
    patience=8,           # evaluations without improvement before stopping
    val_days=1024,        # fixed validation subset for CRPS
    val_scenarios=20,
    val_steps=25,         # DDIM steps during validation (final evaluation uses more)
)

# Optuna search space (documented in the paper as the tuning protocol)
SEARCH_SPACE = {
    "lr": ("loguniform", 5e-5, 1e-3),
    "weight_decay": ("loguniform", 1e-6, 1e-3),
    "dropout": ("uniform", 0.0, 0.3),
    "base_ch": ("categorical", [32, 64, 96]),
    "schedule": ("categorical", ["cosine", "linear"]),
    "T": ("categorical", [100, 200, 500]),
    "batch_size": ("categorical", [128, 256]),
}
MODEL_KEYS = set(M.MODEL_CFG)


def md5(path, n=1 << 20):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(n), b""):
            h.update(c)
    return h.hexdigest()


def environment():
    env = dict(python=platform.python_version(), torch=torch.__version__,
               numpy=np.__version__, os=platform.platform())
    if torch.cuda.is_available():
        env.update(cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(0),
                   cudnn=torch.backends.cudnn.version())
    return env


class EMA:
    def __init__(self, model, decay):
        self.decay = decay
        self.model = copy.deepcopy(model).eval()
        for p in self.model.parameters():
            p.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        for pe, p in zip(self.model.parameters(), model.parameters()):
            pe.mul_(self.decay).add_(p.detach(), alpha=1 - self.decay)
        for be, b in zip(self.model.buffers(), model.buffers()):
            be.copy_(b)


@torch.no_grad()
def evaluate(model, d, idx, dev, tc, seed=1234):
    """Validation CRPS (k_c, masked) and diffusion loss with fixed randomness."""
    model.eval()
    g = torch.Generator(device=dev).manual_seed(seed)
    # Also fix the GLOBAL RNG during evaluation (MC-dropout masks use it), then
    # restore it so training randomness is unaffected.
    cpu_state = torch.random.get_rng_state()
    cuda_state = torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
    torch.manual_seed(seed)
    crps_sum, w_sum, loss_sum, n = 0.0, 0.0, 0.0, 0
    for s in range(0, len(idx), 256):
        b = M.to_batch(d, idx[s:s + 256], dev)
        S = model.sample(b, K=tc["val_scenarios"], steps=tc["val_steps"], generator=g)
        w = float(b["m_y"].sum())
        crps_sum += M.crps_ensemble(S, b["y"], b["m_y"]) * w
        w_sum += w
        t = torch.randint(0, model.mc["T"], (len(b["y"]),), device=dev, generator=g)
        noise = torch.randn(b["y"].shape, device=dev, generator=g)
        loss_sum += model.loss(b, t, noise).item() * len(b["y"])
        n += len(b["y"])
    torch.random.set_rng_state(cpu_state)
    if cuda_state is not None:
        torch.cuda.set_rng_state_all(cuda_state)
    return crps_sum / w_sum, loss_sum / n


def train_one(data, info, experiment, seed, mc, tc, run_dir, exclude_sites=None,
              log_prefix="", quiet=False, model_fn=None):
    os.makedirs(run_dir, exist_ok=True)
    cfg.set_seed(seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tr = M.load_split(data, "train", experiment, exclude_sites=exclude_sites)
    va = M.load_split(data, "val", experiment, exclude_sites=exclude_sites)
    dims = M.dims_from_info(info)
    model = (model_fn(dims, mc) if model_fn else M.GenerativeAURORA(dims, mc)).to(dev)
    ema = EMA(model, tc["ema_decay"])
    opt = torch.optim.AdamW(model.parameters(), lr=tc["lr"], weight_decay=tc["weight_decay"])

    n = len(tr["y"])
    steps_per_epoch = int(np.ceil(n / tc["batch_size"]))
    total = steps_per_epoch * tc["epochs"]

    def lr_at(step):
        if step < tc["warmup_steps"]:
            return tc["lr"] * (step + 1) / tc["warmup_steps"]
        p = (step - tc["warmup_steps"]) / max(1, total - tc["warmup_steps"])
        return 1e-6 + 0.5 * (tc["lr"] - 1e-6) * (1 + np.cos(np.pi * min(1.0, p)))

    rng = np.random.default_rng(seed)
    val_idx = np.sort(np.random.default_rng(999).choice(len(va["y"]), min(tc["val_days"], len(va["y"])),
                                                        replace=False))
    log_path = os.path.join(run_dir, "train_log.csv")
    best = dict(crps=float("inf"), epoch=-1, val_loss=None)
    bad, step, t0 = 0, 0, time.time()
    with open(log_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["epoch", "train_loss", "val_loss", "val_crps", "lr", "seconds"])
        for ep in range(1, tc["epochs"] + 1):
            model.train()
            perm = rng.permutation(n)
            tl, nb = 0.0, 0
            for s in range(0, n, tc["batch_size"]):
                for g_ in opt.param_groups:
                    g_["lr"] = lr_at(step)
                b = M.to_batch(tr, perm[s:s + tc["batch_size"]], dev)
                loss = model.loss(b)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), tc["grad_clip"])
                opt.step()
                ema.update(model)
                tl += loss.item(); nb += 1; step += 1
            row = [ep, tl / nb, "", "", lr_at(step), round(time.time() - t0, 1)]
            if ep % tc["eval_every"] == 0 or ep == tc["epochs"]:
                crps, vloss = evaluate(ema.model, va, val_idx, dev, tc)
                row[2], row[3] = vloss, crps
                if crps < best["crps"] - 1e-5:
                    best = dict(crps=crps, epoch=ep, val_loss=vloss)
                    torch.save(dict(state_dict=ema.model.state_dict(), mc=model.mc, dims=dims,
                                    experiment=experiment, seed=seed, epoch=ep,
                                    model_class=type(model).__name__),
                               os.path.join(run_dir, "best.pt"))
                    bad = 0
                else:
                    bad += 1
                if not quiet:
                    print(f"{log_prefix}epoch {ep:3d}  train {tl / nb:.4f}  val loss {vloss:.4f}  "
                          f"val CRPS(k_c) {crps:.4f}  best {best['crps']:.4f}@{best['epoch']}  "
                          f"[{time.time() - t0:.0f}s]")
                if bad >= tc["patience"]:
                    w.writerow(row)
                    if not quiet:
                        print(f"{log_prefix}early stop: no improvement for {tc['patience']} evaluations")
                    break
            w.writerow(row)
            f.flush()

    summary = dict(experiment=experiment, seed=seed, best_epoch=best["epoch"],
                   best_val_crps=best["crps"], best_val_loss=best["val_loss"],
                   n_train=n, n_val=len(va["y"]), params=M.count_params(model),
                   minutes=round((time.time() - t0) / 60, 2), model_cfg=model.mc, train_cfg=tc,
                   excluded_sites=sorted(exclude_sites) if exclude_sites else [],
                   dataset_md5=md5(M.DATA_NPZ), environment=environment(),
                   finished=datetime.now().isoformat(timespec="seconds"))
    with open(os.path.join(run_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2, default=str)
    return summary


def split_params(p):
    mc = {k: v for k, v in p.items() if k in MODEL_KEYS}
    tc = {k: v for k, v in p.items() if k not in MODEL_KEYS}
    return mc, tc


def tune(data, info, experiment, n_trials, tune_epochs, base_mc, base_tc, exclude_sites):
    try:
        import optuna
    except ImportError:
        sys.exit("Optuna is not installed:  python -m pip install optuna")
    out_dir = os.path.join(cfg.RESULT_DIR, "tuning")
    os.makedirs(out_dir, exist_ok=True)

    def objective(trial):
        p = {}
        for k, spec in SEARCH_SPACE.items():
            if spec[0] == "loguniform":
                p[k] = trial.suggest_float(k, spec[1], spec[2], log=True)
            elif spec[0] == "uniform":
                p[k] = trial.suggest_float(k, spec[1], spec[2])
            else:
                p[k] = trial.suggest_categorical(k, spec[1])
        mc_p, tc_p = split_params(p)
        mc = dict(base_mc, **mc_p)
        tc = dict(base_tc, **tc_p, epochs=tune_epochs, patience=4)
        run_dir = os.path.join(cfg.CKPT_DIR, f"tune_{experiment}", f"trial_{trial.number:03d}")
        s = train_one(data, info, experiment, 0, mc, tc, run_dir, exclude_sites,
                      log_prefix=f"[trial {trial.number}] ", quiet=True)
        print(f"trial {trial.number:3d}: val CRPS {s['best_val_crps']:.4f}  {p}")
        return s["best_val_crps"]

    study = optuna.create_study(direction="minimize",
                                sampler=optuna.samplers.TPESampler(seed=cfg.SEEDS[0]))
    study.optimize(objective, n_trials=n_trials)
    study.trials_dataframe().to_csv(os.path.join(out_dir, f"{experiment}_trials.csv"), index=False)
    best_path = os.path.join(out_dir, f"{experiment}_best_params.json")
    with open(best_path, "w") as f:
        json.dump(dict(best_params=study.best_params, best_val_crps=study.best_value,
                       n_trials=n_trials, tune_epochs=tune_epochs, search_space=SEARCH_SPACE,
                       selection_split="val", sampler="TPE seed %d" % cfg.SEEDS[0]), f, indent=2)
    print(f"\nbest val CRPS {study.best_value:.4f} with {study.best_params}")
    print(f"saved: {best_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--experiment", default="main", choices=["main", "alt"])
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--name", default="", help="suffix for the run folder (e.g. lin, ablation)")
    ap.add_argument("--schedule", choices=["cosine", "linear"])
    ap.add_argument("--T", type=int)
    ap.add_argument("--base-ch", type=int, help="U-Net width (e.g. 32 for a parameter-matched model)")
    ap.add_argument("--epochs", type=int)
    ap.add_argument("--params", help="JSON with best_params from --tune")
    ap.add_argument("--tune", type=int, default=0, help="number of Optuna trials")
    ap.add_argument("--tune-epochs", type=int, default=60)
    ap.add_argument("--exclude-regions", default="", help="comma-separated regions left out")
    args = ap.parse_args()

    if not os.path.exists(M.DATA_NPZ):
        sys.exit("dataset not found: run 4_build_dataset.py first")
    data = dict(np.load(M.DATA_NPZ, allow_pickle=True))
    info = M.load_info()

    mc, tc = dict(M.MODEL_CFG), dict(TRAIN_CFG)
    if args.params:
        with open(args.params) as f:
            mc_p, tc_p = split_params(json.load(f)["best_params"])
        mc.update(mc_p); tc.update(tc_p)
        print(f"using tuned parameters from {args.params}")
    if args.schedule:
        mc["schedule"] = args.schedule
    if args.T:
        mc["T"] = args.T
    if args.base_ch:
        mc["base_ch"] = args.base_ch
    if args.epochs:
        tc["epochs"] = args.epochs

    exclude_sites = None
    regions = [r for r in args.exclude_regions.split(",") if r]
    if regions:
        unknown = set(regions) - set(np.unique(data["region"]))
        if unknown:
            sys.exit(f"unknown region(s): {sorted(unknown)}")
        exclude_sites = set(data["site_id"][np.isin(data["region"], regions)])
        print(f"leaving out regions {regions}: {len(exclude_sites)} sites never seen in training")

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"device: {dev}" + (f" ({torch.cuda.get_device_name(0)})" if dev == "cuda" else
                               "  !! no GPU found - training will be slow"))

    if args.tune:
        tune(data, info, args.experiment, args.tune, args.tune_epochs, mc, tc, exclude_sites)
        return

    tag = args.experiment + (f"_{args.name}" if args.name else "") + \
        (f"_holdout-{'-'.join(regions)}" if regions else "")
    results = []
    for seed in [int(s) for s in args.seeds.split(",")]:
        run_dir = os.path.join(cfg.CKPT_DIR, tag, f"seed{seed}")
        print(f"\n=== {tag}  seed {seed}  -> {run_dir}")
        print(f"model: {mc}")
        s = train_one(data, info, args.experiment, seed, mc, tc, run_dir, exclude_sites,
                      log_prefix=f"[seed {seed}] ")
        results.append(s)
        print(f"seed {seed}: best val CRPS {s['best_val_crps']:.4f} at epoch {s['best_epoch']} "
              f"({s['minutes']} min)")

    out = os.path.join(cfg.RESULT_DIR, "training")
    os.makedirs(out, exist_ok=True)
    path = os.path.join(out, f"{tag}_seeds.csv")
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["seed", "best_epoch", "best_val_crps", "best_val_loss", "minutes", "params"])
        for s in results:
            w.writerow([s["seed"], s["best_epoch"], round(s["best_val_crps"], 5),
                        round(s["best_val_loss"], 5), s["minutes"], s["params"]])
    v = np.array([s["best_val_crps"] for s in results])
    print(f"\n{tag}: val CRPS {v.mean():.4f}" + (f" +/- {v.std(ddof=1):.4f} over {len(v)} seeds"
                                                if len(v) > 1 else ""))
    print(f"summary: {path}")


if __name__ == "__main__":
    main()