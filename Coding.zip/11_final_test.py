"""
GenerativeAURORA v2 - 11_final_test.py
======================================
The ONE-TIME evaluation on the test year 2020, with everything frozen first.

Steps
  0. Write Results/final/frozen_protocol.json BEFORE touching the test set:
     primary model, calibration method, metrics, references, decision rules and
     the MD5 of every checkpoint. If the file already exists, the checkpoints
     are verified against it (a changed model after the test is flagged).
  1. Temporal test (2020): scenarios -> calibration (7_calibrate) -> scores
     (8_evaluate) for every frozen run, the 4 baselines included.
  2. Comparison table on 2020 (9_baselines --compare logic).
  3. Paired significance tests, primary model vs every other model, on per-day
     CRPS, energy and variogram scores (seed-averaged), with a moving-block
     bootstrap over dates (7-day blocks: weather is autocorrelated).
  4. Spatial test (2020): leave-one-region-out with the frozen small model,
     plus an exact sign-flip permutation test with the 7 REGIONS as units.
  5. Optional (--alt): robustness protocol 2016-17 train / 2018 val+cal /
     2019 test for the primary model (answers the 2020 data-version question).

Usage
    python 11_final_test.py              # steps 0-4  (~1.5-2 h)
    python 11_final_test.py --alt        # + robustness protocol (~1.5 h more)
    python 11_final_test.py --stats-only # only redo the significance tests
"""

import os
import sys
import json
import glob
import hashlib
import argparse
import itertools
import subprocess
import importlib
from datetime import datetime

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
cfg = importlib.import_module("1_config")
E = importlib.import_module("8_evaluate")

OUT_DIR = os.path.join(cfg.RESULT_DIR, "final")
SCEN_DIR = os.path.join(cfg.RESULT_DIR, "scenarios")
CAL_DIR = os.path.join(cfg.RESULT_DIR, "calibration")
PROTOCOL = os.path.join(OUT_DIR, "frozen_protocol.json")

PRIMARY = "main_small"
GA_RUNS = ["main_small", "main_tuned", "main_tuned_linear"]
BASE_RUNS = ["base_lstmqr", "base_transqr", "base_cvae", "base_mcdrop"]
N_BOOT = 2000
BLOCK = 7


def run(cmd):
    print("\n>>> " + " ".join(cmd))
    r = subprocess.run([sys.executable] + cmd, cwd=HERE)
    if r.returncode != 0:
        sys.exit(f"step failed: {' '.join(cmd)}")


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def checkpoints():
    out = {}
    for r in GA_RUNS + BASE_RUNS:
        for p in sorted(glob.glob(os.path.join(cfg.CKPT_DIR, r, "seed*", "best.pt"))):
            out[os.path.relpath(p, cfg.CKPT_DIR)] = md5(p)
    for p in sorted(glob.glob(os.path.join(cfg.CKPT_DIR, "holdout_*", "*", "seed*", "best.pt"))):
        if "ga_bc24" in p or os.sep + "tqr" + os.sep in p:
            out[os.path.relpath(p, cfg.CKPT_DIR)] = md5(p)
    return out


def freeze():
    os.makedirs(OUT_DIR, exist_ok=True)
    ck = checkpoints()
    if os.path.exists(PROTOCOL):
        old = json.load(open(PROTOCOL))
        changed = [k for k, v in old["checkpoints"].items() if ck.get(k) not in (None, v)]
        missing = [k for k in old["checkpoints"] if k not in ck]
        print(f"frozen protocol from {old['frozen_at']} found; {len(ck)} checkpoints verified")
        if changed or missing:
            print("!! WARNING: checkpoints changed/missing since freezing: " + ", ".join(changed + missing))
        return
    proto = dict(
        frozen_at=datetime.now().isoformat(timespec="seconds"),
        primary_model=PRIMARY,
        primary_model_reason="validation: in-domain equal to main_tuned (CRPS 0.1148 vs 0.1147); "
                             "leave-one-region-out: lower CRPS (0.1229 vs 0.1248), smaller "
                             "generalisation gap (6.7% vs 8.8%), half the seed spread, energy and "
                             "variogram better than Transformer-QR in 21/21 region-seeds",
        hyperparameters="Results/tuning/main_best_params.json (validation only), base_ch=24",
        calibration_primary="mondrian 90% on previous-day regime, fitted on 'cal' split; point-mass "
                            "snap fitted on 'cal'; marginal and trajectory also reported",
        metrics=["CRPS (k_c, W/m2)", "CRPSS vs CLIM and PERS", "MAE", "RMSE", "energy score",
                 "variogram score p=0.5", "PIT reliability", "90% coverage", "width", "interval score"],
        references=["CLIM (same site, +/-15 days, training years)", "PERS (previous day)"],
        baselines=BASE_RUNS, other_ga_runs=[r for r in GA_RUNS if r != PRIMARY],
        significance=f"moving-block bootstrap over dates, block {BLOCK} days, {N_BOOT} resamples, "
                     "seed-averaged per-day scores, two-sided; spatial: exact sign-flip test over 7 regions",
        test_split="2020 (split_main == 'test'), opened once",
        checkpoints=ck)
    with open(PROTOCOL, "w") as f:
        json.dump(proto, f, indent=2)
    print(f"protocol frozen: {PROTOCOL} ({len(ck)} checkpoints fingerprinted)")


def baseline_test_scenarios():
    B = importlib.import_module("9_baselines")
    data = None
    for name, cls in B.MODELS.items():
        r = f"base_{name}"
        for d in sorted(glob.glob(os.path.join(cfg.CKPT_DIR, r, "seed*"))):
            seed = int(os.path.basename(d)[4:])
            if os.path.exists(os.path.join(SCEN_DIR, r, f"seed{seed}_test.npz")):
                continue
            if data is None:
                data = dict(np.load(os.path.join(cfg.PROC_DIR, "aurora_dataset.npz"), allow_pickle=True))
            B.generate(cls, r, seed, "test", data)


# ----------------------------------------------------------------------------
def per_day(run_name, target="test"):
    """Seed-averaged per-day CRPS / energy / variogram for one run."""
    files = sorted(glob.glob(os.path.join(SCEN_DIR, run_name, f"seed*_{target}.npz")))
    if not files:
        return None
    acc, dates, sites = [], None, None
    for f in files:
        seed = int(os.path.basename(f).split("_")[0][4:])
        sc = dict(np.load(f, allow_pickle=True))
        q = os.path.join(CAL_DIR, f"{run_name}_seed{seed}_q.json")
        delta = json.load(open(q)).get("snap_delta", 0.0) if os.path.exists(q) else 0.0
        S = sc["S"].astype(np.float32)
        if delta > 0:
            S = np.where(S >= 1 - delta, 1.0, S)
        y, m = sc["y"].astype(np.float32), sc["m_y"].astype(np.float32)
        acc.append(np.stack([E.crps_days(S, y, m), E.energy_days(S, y, m), E.variogram_days(S, y, m)], 1))
        dates, sites = sc["date"], sc["site_id"]
    return np.mean(acc, 0), dates, sites


def block_bootstrap(diff, dates, rng):
    """diff per site-day -> mean per date -> moving-block bootstrap of the mean."""
    s = pd.Series(diff).groupby(pd.Series(dates)).mean().sort_index().values
    n = len(s)
    nb = int(np.ceil(n / BLOCK))
    starts = rng.integers(0, n - BLOCK + 1, size=(N_BOOT, nb))
    idx = (starts[:, :, None] + np.arange(BLOCK)[None, None, :]).reshape(N_BOOT, -1)[:, :n]
    boots = s[idx].mean(1)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    p = 2 * min((boots <= 0).mean(), (boots >= 0).mean())
    return s.mean(), lo, hi, max(p, 1.0 / N_BOOT)


def significance(target="test"):
    rng = np.random.default_rng(0)
    prim = per_day(PRIMARY, target)
    if prim is None:
        sys.exit(f"no {PRIMARY} '{target}' scenarios")
    P, dates, sites = prim
    rows = []
    for other in [r for r in GA_RUNS if r != PRIMARY] + BASE_RUNS:
        o = per_day(other, target)
        if o is None:
            continue
        O, d2, s2 = o
        if not (np.array_equal(d2, dates) and np.array_equal(s2, sites)):
            print(f"!! {other}: day order differs - skipped")
            continue
        for k, met in enumerate(["CRPS", "energy", "variogram"]):
            diff = O[:, k] - P[:, k]                      # > 0: primary model better
            mean, lo, hi, p = block_bootstrap(diff, dates, rng)
            rows.append(dict(comparison=f"{PRIMARY} vs {other}", metric=met,
                             primary=P[:, k].mean(), other=O[:, k].mean(),
                             improvement_pct=100 * mean / O[:, k].mean(),
                             diff_ci_lo=lo, diff_ci_hi=hi, p_value=p,
                             verdict=("primary better" if lo > 0 else
                                      "other better" if hi < 0 else "no significant difference")))
    # schedule ablation: same width (96), only the noise schedule differs.
    # Appended AFTER the main loop so the existing p-values are unchanged.
    a, b = per_day("main_tuned", target), per_day("main_tuned_linear", target)
    if a is not None and b is not None and np.array_equal(a[1], b[1]) and np.array_equal(a[2], b[2]):
        for k, met in enumerate(["CRPS", "energy", "variogram"]):
            diff = b[0][:, k] - a[0][:, k]                # > 0: cosine better
            mean, lo, hi, p = block_bootstrap(diff, a[1], rng)
            rows.append(dict(comparison="ABLATION main_tuned (cosine) vs main_tuned_linear (linear)",
                             metric=met, primary=a[0][:, k].mean(), other=b[0][:, k].mean(),
                             improvement_pct=100 * mean / b[0][:, k].mean(),
                             diff_ci_lo=lo, diff_ci_hi=hi, p_value=p,
                             verdict=("primary better" if lo > 0 else
                                      "other better" if hi < 0 else "no significant difference")))
    df = pd.DataFrame(rows)
    # Holm-Bonferroni correction, three families: (a) vs the 4 baselines, (b) vs other GA variants
    df["family"] = np.where(df.comparison.str.startswith("ABLATION"), "schedule ablation",
                            np.where(df.comparison.str.contains("base_"), "baselines", "GA variants"))
    df["p_holm"] = np.nan
    for fam, g in df.groupby("family"):
        order = g.p_value.sort_values().index
        m, running = len(order), 0.0
        for i, idx in enumerate(order):
            running = max(running, min(1.0, (m - i) * df.at[idx, "p_value"]))
            df.at[idx, "p_holm"] = running
    sig = df.p_holm < 0.05
    df["verdict_holm"] = np.where(~sig, "no significant difference",
                                  np.where(df.diff_ci_lo > 0, "primary better", "other better"))
    os.makedirs(OUT_DIR, exist_ok=True)
    df.to_csv(os.path.join(OUT_DIR, f"significance_{target}.csv"), index=False)
    return df


def spatial_permutation(target="test"):
    p = os.path.join(cfg.RESULT_DIR, "spatial", f"spatial_{target}_bc24_raw.csv")
    if not os.path.exists(p):
        return None
    df = pd.read_csv(p)
    loc = df[df.setting == "local"].groupby(["region", "model"])[["crps_kc", "energy", "variogram"]] \
        .mean().unstack("model")
    out = []
    for met in ["crps_kc", "energy", "variogram"]:
        d = (loc[(met, "TransformerQR")] - loc[(met, "GenerativeAURORA")]).values   # >0: GA better
        obs = d.mean()
        flips = np.array(list(itertools.product([-1, 1], repeat=len(d))))
        null = (flips * d).mean(1)
        pval = (np.abs(null) >= abs(obs) - 1e-12).mean()
        out.append(dict(metric=met, regions=len(d), ga_better_in=int((d > 0).sum()),
                        mean_diff=obs, rel_pct=100 * obs / loc[(met, "TransformerQR")].mean(),
                        exact_p=pval))
    return pd.DataFrame(out)


def write_report(target, sig, sp):
    lines = [f"GenerativeAURORA v2 - FINAL {target.upper()} RESULTS  "
             f"{datetime.now().isoformat(timespec='seconds')}",
             f"frozen protocol: {PROTOCOL}", f"primary model: {PRIMARY}"]
    comp = os.path.join(cfg.RESULT_DIR, "baselines", f"comparison_{target}.txt")
    if os.path.exists(comp):
        lines += ["\n=== 1. TEMPORAL TEST: all models (mean over seeds) ===", open(comp).read()]
    if sig is not None and len(sig):
        lines.append("\n=== 2. PAIRED SIGNIFICANCE (seed-averaged per-day scores; "
                     f"{BLOCK}-day block bootstrap over dates, {N_BOOT} resamples) ===")
        lines.append("improvement_pct > 0 means the primary model is better; verdict uses the 95% CI")
        t = sig.copy()
        for c in ["primary", "other"]:
            t[c] = t[c].round(5)
        t["improvement_pct"] = t["improvement_pct"].round(2)
        t["p_value"] = t["p_value"].map(lambda v: f"{v:.4f}")
        t["p_holm"] = t["p_holm"].map(lambda v: f"{v:.4f}")
        lines.append("p_holm = Holm-Bonferroni within family (baselines: 12 tests; GA variants: 6 tests; "
                     "schedule ablation: 3 tests); verdict_holm is the one to report")
        lines.append("ABLATION rows: 'primary' = cosine (96 ch), 'other' = linear (96 ch), same settings otherwise")
        lines.append(t[["comparison", "metric", "primary", "other", "improvement_pct",
                        "p_value", "p_holm", "verdict_holm"]].to_string(index=False))
    sp_rep = os.path.join(cfg.RESULT_DIR, "spatial", f"spatial_{target}_bc24_report.txt")
    if os.path.exists(sp_rep):
        txt = open(sp_rep).read()
        lines += ["\n=== 3. SPATIAL TEST (leave-one-region-out) ===",
                  txt[txt.find("=== MEAN OVER ALL"):]]
    if sp is not None:
        lines.append("\nexact sign-flip permutation test, 7 regions as units "
                     "(GenerativeAURORA-small vs Transformer-QR, local setting):")
        lines.append(sp.round(4).to_string(index=False))
    alt = os.path.join(cfg.RESULT_DIR, "evaluation", "alt_small_test_evaluation_report.txt")
    if os.path.exists(alt):
        a = open(alt).read()
        lines += ["\n=== 4. ROBUSTNESS: alternative protocol (train 2016-17, test 2019) ===",
                  a[a.find("=== GenerativeAURORA across seeds"):] if "across seeds" in a else a[:3000]]
    rep = os.path.join(OUT_DIR, f"final_{target}_report.txt")
    with open(rep, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\n".join(lines))
    print(f"\nFINAL REPORT: {rep}  -> send this file to Claude")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--alt", action="store_true", help="also run the 2019 robustness protocol")
    ap.add_argument("--stats-only", action="store_true")
    args = ap.parse_args()
    os.makedirs(OUT_DIR, exist_ok=True)

    if not args.stats_only:
        freeze()
        print("\n######## 1. temporal test 2020")
        baseline_test_scenarios()
        for r in GA_RUNS + BASE_RUNS:
            if glob.glob(os.path.join(cfg.CKPT_DIR, r, "seed*", "best.pt")):
                run(["7_calibrate.py", "--run", r, "--target", "test"])
                run(["8_evaluate.py", "--run", r, "--target", "test"])
        B = importlib.import_module("9_baselines")
        B.compare("test")
        print("\n######## 4. spatial test 2020 (frozen small model)")
        run(["10_spatial_holdout.py", "--target", "test", "--ga-base-ch", "24"])
        if args.alt:
            print("\n######## 5. robustness protocol (test 2019)")
            if not glob.glob(os.path.join(cfg.CKPT_DIR, "alt_small", "seed*", "best.pt")):
                run(["6_train.py", "--params", "Results/tuning/main_best_params.json",
                     "--experiment", "alt", "--name", "small", "--base-ch", "24",
                     "--seeds", "0,1,2,3,4"])
            run(["7_calibrate.py", "--run", "alt_small", "--target", "test"])
            run(["8_evaluate.py", "--run", "alt_small", "--target", "test"])

    print("\n######## 3. paired significance tests")
    sig = significance("test")
    sp = spatial_permutation("test")
    write_report("test", sig, sp)


if __name__ == "__main__":
    main()